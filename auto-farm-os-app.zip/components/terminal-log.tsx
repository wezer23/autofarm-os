'use client'

import { useEffect, useRef, useState } from 'react'

const SYS_ENTRIES = [
  ['SYS::OK', 'sensor waterTemp OK 27.5°C'],
  ['AI::WARN', 'O2 minor drift detected'],
  ['SYS::ACK', 'feeding confirmed Pool-2'],
  ['SYS::OK', 'ventilation cycle complete'],
  ['AI::INFO', 'molting probability Pool-2 rising'],
  ['SYS::OK', 'sensor pH OK 7.8'],
  ['NODE-A', 'heartbeat ack 12ms'],
  ['AI::OK', 'thermal protocol nominal'],
  ['SYS::OK', 'ammonia 0.008 mg/L nominal'],
  ['NODE-C', 'connection timeout retry'],
  ['AI::INFO', 'biomass estimate +0.4kg'],
  ['SYS::ACK', 'aeration Pool-1 ON'],
]

function ts() {
  const d = new Date()
  return d.toTimeString().slice(0, 8)
}

const TAG_COLOR: Record<string, string> = {
  'SYS::OK': 'var(--green)',
  'SYS::ACK': 'var(--cyan)',
  'AI::WARN': 'var(--orange)',
  'AI::INFO': 'var(--purple)',
  'AI::OK': 'var(--green)',
  'NODE-A': 'var(--cyan)',
  'NODE-C': 'var(--red)',
}

export function TerminalLog({ height = 'h-40' }: { height?: string }) {
  const [lines, setLines] = useState<{ t: string; tag: string; msg: string }[]>(() =>
    SYS_ENTRIES.slice(0, 6).map(([tag, msg]) => ({ t: ts(), tag, msg })),
  )
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const id = setInterval(() => {
      const [tag, msg] = SYS_ENTRIES[Math.floor(Math.random() * SYS_ENTRIES.length)]
      setLines((prev) => [...prev.slice(-30), { t: ts(), tag, msg }])
    }, 3200)
    return () => clearInterval(id)
  }, [])

  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight
  }, [lines])

  return (
    <div
      ref={ref}
      className={`no-scrollbar ${height} overflow-y-auto rounded-lg border bg-[var(--background)] p-3 font-mono text-[11px] leading-relaxed`}
    >
      {lines.map((l, i) => (
        <div key={i} className="flex gap-2">
          <span className="text-muted-foreground">[{l.t}]</span>
          <span style={{ color: TAG_COLOR[l.tag] ?? 'var(--cyan)' }} className="font-semibold">
            {l.tag}
          </span>
          <span className="text-foreground/80">{l.msg}</span>
        </div>
      ))}
    </div>
  )
}
