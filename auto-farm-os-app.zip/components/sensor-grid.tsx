'use client'

import {
  type Config,
  tempStatus,
  o2Status,
  phStatus,
  ammoniaStatus,
  humidityStatus,
  statusColor,
} from '@/lib/config'
import { StatusDot } from './ui-kit'

export function SensorGrid({ config }: { config: Config }) {
  const cells = [
    { label: 'ТЕМП.ВОДИ', value: config.waterTemp.toFixed(1), unit: '°C', color: statusColor[tempStatus(config.waterTemp, config)] },
    { label: 'КИСЕНЬ', value: config.oxygen.toFixed(1), unit: 'mg/L', color: statusColor[o2Status(config.oxygen, config)] },
    { label: 'pH', value: config.pH.toFixed(2), unit: '', color: statusColor[phStatus(config.pH, config)] },
    { label: 'АМІАК', value: config.ammonia.toFixed(3), unit: 'mg/L', color: statusColor[ammoniaStatus(config.ammonia, config)] },
    { label: 'ВОЛОГІСТЬ', value: config.humidity.toFixed(0), unit: '%', color: statusColor[humidityStatus(config.humidity, config)] },
    { label: 'ТЕМП.ПОВІТРЯ', value: config.airTemp.toFixed(1), unit: '°C', color: 'var(--cyan)' },
  ]
  return (
    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
      {cells.map((c) => (
        <div
          key={c.label}
          className="rounded-lg border bg-card p-3"
          style={{ borderColor: c.color + '55' }}
        >
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-wide text-muted-foreground">{c.label}</span>
            <StatusDot color={c.color} />
          </div>
          <div className="font-mono text-lg font-bold" style={{ color: c.color }}>
            {c.value}
            <span className="ml-1 text-[10px] text-muted-foreground">{c.unit}</span>
          </div>
        </div>
      ))}
    </div>
  )
}
