'use client'

import { Card, SectionTitle, StatusDot, Toggle } from '@/components/ui-kit'
import { SensorGrid } from '@/components/sensor-grid'
import { TerminalLog } from '@/components/terminal-log'
import { humidityStatus, statusColor } from '@/lib/config'
import type { PageProps } from './types'
import { ShieldCheck, Waves, Thermometer, Wind } from 'lucide-react'

export function HomePage({ config, update }: PageProps) {
  const stats = [
    { label: 'Басейни', value: '3' },
    { label: 'Ø Темп', value: `${config.waterTemp.toFixed(1)}°C` },
    { label: 'Ø O₂', value: config.oxygen.toFixed(1) },
    { label: 'Тривоги', value: '0' },
  ]

  const humColor = statusColor[humidityStatus(config.humidity, config)]
  const ventTip =
    config.humidity > config.humidityMax
      ? { text: '🚨 КРИТИЧНА вологість - вентиляція 100%!', color: 'var(--red)' }
      : config.humidity >= 75
        ? { text: '⚠️ Підвищена вологість - збільшіть вентиляцію', color: 'var(--orange)' }
        : { text: '✓ Вентиляція в нормі', color: 'var(--green)' }

  const setIntake = (v: number) => {
    update('intakeFanSpeed', v)
    if (config.fanSyncMode) update('exhaustFanSpeed', v)
  }

  return (
    <div>
      <header className="mb-4 px-1">
        <h1 className="text-xl font-bold tracking-tight">AutoFarm OS</h1>
        <p className="text-xs text-muted-foreground">Cherax quadricarinatus · Червоноклешневий рак</p>
      </header>

      {/* Top stat cards */}
      <div className="grid grid-cols-4 gap-2">
        {stats.map((s) => (
          <div key={s.label} className="rounded-lg border bg-card p-2.5 text-center">
            <div className="font-mono text-base font-bold text-[var(--cyan)]">{s.value}</div>
            <div className="mt-0.5 text-[9px] uppercase tracking-wide text-muted-foreground">
              {s.label}
            </div>
          </div>
        ))}
      </div>

      <SectionTitle>ПРОГНОЗИ ШІ</SectionTitle>
      <div className="flex flex-col gap-2">
        <Card accent="var(--cyan)" className="py-3">
          <p className="text-sm">🦞 Линяння: <span className="text-muted-foreground">{config.pool2Name}</span> → <span className="font-mono text-[var(--cyan)]">~3 дні</span></p>
        </Card>
        <Card accent="var(--cyan)" className="py-3">
          <p className="text-sm">📦 Збір: <span className="text-muted-foreground">{config.pool3Name}</span> → <span className="font-mono text-[var(--cyan)]">~11 днів (~18кг)</span></p>
        </Card>
        <Card accent="var(--cyan)" className="py-3">
          <p className="text-sm">🌡️ Температура стабільна <span className="font-mono text-[var(--green)]">{config.tempOptimalMin}-{config.tempOptimalMax}°C</span></p>
        </Card>
      </div>

      <SectionTitle>КЛІМАТ І ВЕНТИЛЯЦІЯ</SectionTitle>
      <Card>
        <div className="flex items-center justify-between py-1">
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Waves size={15} /> Вологість
          </span>
          <span className="flex items-center gap-2">
            <span className="font-mono text-sm font-semibold" style={{ color: humColor }}>
              {config.humidity.toFixed(0)}%
            </span>
            <StatusDot color={humColor} />
          </span>
        </div>
        <div className="flex items-center justify-between py-1">
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Thermometer size={15} /> Темп. повітря
          </span>
          <span className="font-mono text-sm font-semibold">{config.airTemp.toFixed(1)}°C</span>
        </div>

        <div className="my-3 border-t" />

        <div className="mb-1 flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-xs uppercase tracking-wide text-muted-foreground">
            <Wind size={13} /> Приплив (Air Intake)
          </span>
          <span className="font-mono text-sm font-semibold text-[var(--cyan)]">
            {config.intakeFanSpeed}%
          </span>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={config.intakeFanSpeed}
          onChange={(e) => setIntake(Number(e.target.value))}
          className="mb-4"
        />

        <div className="mb-1 flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-xs uppercase tracking-wide text-muted-foreground">
            <Wind size={13} /> Витяжка (Air Exhaust)
          </span>
          <span className="font-mono text-sm font-semibold text-[var(--cyan)]">
            {config.exhaustFanSpeed}%
          </span>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={config.exhaustFanSpeed}
          onChange={(e) => update('exhaustFanSpeed', Number(e.target.value))}
          className="mb-4"
        />

        <div className="flex items-center justify-between border-t pt-3">
          <span className="text-sm">🔗 Синхронний режим</span>
          <Toggle checked={config.fanSyncMode} onChange={(v) => update('fanSyncMode', v)} />
        </div>

        <div
          className="mt-3 rounded-lg px-3 py-2 text-xs font-medium"
          style={{ backgroundColor: ventTip.color + '1a', color: ventTip.color }}
        >
          {ventTip.text}
        </div>
      </Card>

      <SectionTitle>ШІ СТАТУС</SectionTitle>
      <Card accent="var(--green)">
        <div className="mb-3 flex items-center gap-3">
          <div
            className="flex h-9 w-9 items-center justify-center rounded-lg"
            style={{ backgroundColor: 'var(--green)1a' }}
          >
            <ShieldCheck size={20} color="var(--green)" />
          </div>
          <div>
            <p className="text-sm font-semibold" style={{ color: 'var(--green)' }}>
              ШІ СТАТУС: Нормальна Робота
            </p>
            <p className="text-xs text-muted-foreground">Всі датчики в межах норми</p>
          </div>
        </div>
        <TerminalLog height="h-36" />
      </Card>

      <SectionTitle>ДАТЧИКИ ЗАРАЗ</SectionTitle>
      <SensorGrid config={config} />
    </div>
  )
}
