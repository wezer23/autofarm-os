import type { Config } from '@/lib/config'

export type Update = <K extends keyof Config>(key: K, value: Config[K]) => void
export type UpdateMany = (patch: Partial<Config>) => void

export interface PageProps {
  config: Config
  update: Update
}
