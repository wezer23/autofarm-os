'use client'

import { useState } from 'react'
import {
  Card,
  SectionTitle,
  Btn,
  TextInput,
  Toggle,
  Modal,
  SegButtons,
} from '@/components/ui-kit'
import type { Config } from '@/lib/config'
import type { Update, UpdateMany } from './types'
import { TelegramSection } from './settings/telegram-section'
import { SecuritySection } from './settings/security-section'
import {
  ChevronDown,
  Pencil,
  Zap,
  Battery,
  FlaskRound,
  AppWindow,
  Camera,
  Lightbulb,
  Lock,
} from 'lucide-react'

export function SettingsPage({
  config,
  update,
  updateMany,
}: {
  config: Config
  update: Update
  updateMany: UpdateMany
}) {
  const [editProfile, setEditProfile] = useState(false)
  const [openPool, setOpenPool] = useState<number | null>(null)
  const [soonModal, setSoonModal] = useState<string | null>(null)

  return (
    <div>
      <header className="mb-4 px-1">
        <h1 className="text-xl font-bold tracking-tight">Налаштування</h1>
        <p className="text-xs text-muted-foreground">Конфігурація системи AutoFarm OS</p>
      </header>

      {/* Profile */}
      <Card className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[var(--cyan)] text-base font-bold text-[#001016]">
          AF
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold">{config.adminName}</p>
          <p className="text-xs text-muted-foreground">{config.adminRole}</p>
        </div>
        <Btn variant="outline" className="!px-3 !py-2 !text-xs" onClick={() => setEditProfile(true)}>
          <span className="flex items-center gap-1.5">
            <Pencil size={13} /> РЕДАГУВАТИ
          </span>
        </Btn>
      </Card>

      {/* Farm */}
      <SectionTitle>ФЕРМА</SectionTitle>
      <Card>
        <TextInput
          label="Назва ферми"
          value={config.farmName}
          onChange={(v) => update('farmName', v)}
        />
        <TextInput label="Вид" value="Cherax quadricarinatus" readOnly />
        <TextInput
          label="Загальна площа (м²)"
          value={String(config.totalArea)}
          onChange={(v) => update('totalArea', Number(v) || 0)}
          type="number"
        />
        <div className="mb-1">
          <label className="mb-1.5 block text-xs text-muted-foreground">Дата запуску</label>
          <input
            type="date"
            value={config.launchDate}
            onChange={(e) => update('launchDate', e.target.value)}
            className="w-full rounded-lg border bg-[var(--muted)] px-3 py-2.5 font-mono text-sm text-foreground outline-none focus:border-[var(--cyan)]"
          />
        </div>
      </Card>

      {/* Pools */}
      <SectionTitle>КОНФІГУРАЦІЯ БАСЕЙНІВ</SectionTitle>
      <div className="flex flex-col gap-2">
        {[1, 2, 3].map((n) => {
          const nameKey = `pool${n}Name` as keyof Config
          const countKey = `pool${n}Count` as keyof Config
          const areaKey = `pool${n}Area` as keyof Config
          const open = openPool === n
          return (
            <Card key={n}>
              <button
                className="flex w-full items-center justify-between"
                onClick={() => setOpenPool(open ? null : n)}
              >
                <span className="text-sm font-semibold">{String(config[nameKey])}</span>
                <ChevronDown
                  size={18}
                  className="text-muted-foreground transition-transform"
                  style={{ transform: open ? 'rotate(180deg)' : 'none' }}
                />
              </button>
              {open && (
                <div className="mt-3 animate-fade-in">
                  <TextInput
                    label="Назва басейну"
                    value={String(config[nameKey])}
                    onChange={(v) => update(nameKey, v as never)}
                  />
                  <TextInput
                    label="Кількість особин"
                    value={String(config[countKey])}
                    onChange={(v) => update(countKey, (Number(v) || 0) as never)}
                    type="number"
                  />
                  <TextInput
                    label="Площа м²"
                    value={String(config[areaKey])}
                    onChange={(v) => update(areaKey, (Number(v) || 0) as never)}
                    type="number"
                  />
                  <label className="mb-1.5 block text-xs text-muted-foreground">Стадія</label>
                  <SegButtons
                    options={[
                      { label: 'Молодь', value: 'young' },
                      { label: 'Вирощування', value: 'grow' },
                      { label: 'Товарні', value: 'market' },
                    ]}
                    value={n === 1 ? 'young' : n === 2 ? 'grow' : 'market'}
                    onChange={() => {}}
                  />
                </div>
              )}
            </Card>
          )
        })}
      </div>

      {/* Telegram */}
      <SectionTitle>TELEGRAM БОТ</SectionTitle>
      <TelegramSection config={config} update={update} />

      {/* Notifications */}
      <SectionTitle>СПОВІЩЕННЯ</SectionTitle>
      <Card>
        <LockedRow label="🚨 Критичні тривоги" />
        <ToggleRow label="⚠️ Попередження" checked={config.notifyWarnings} onChange={(v) => update('notifyWarnings', v)} />
        <ToggleRow
          label="📊 Щоденний звіт"
          checked={config.notifyDailyReport}
          onChange={(v) => update('notifyDailyReport', v)}
          extra={config.notifyDailyReport ? <TimePill time="07:00" /> : undefined}
        />
        <ToggleRow label="🦞 Прогноз линяння" checked={config.notifyMolting} onChange={(v) => update('notifyMolting', v)} />
        <ToggleRow label="🍽️ Статус годування" checked={config.notifyFeeding} onChange={(v) => update('notifyFeeding', v)} />
        <ToggleRow label="🤖 Рішення ШІ" checked={config.notifyAI} onChange={(v) => update('notifyAI', v)} />
        <LockedRow label="🔒 Події безпеки" />
        <ToggleRow
          label="🌙 Тихий режим"
          checked={config.notifyQuiet}
          onChange={(v) => update('notifyQuiet', v)}
          extra={config.notifyQuiet ? <TimePill time="23:00-07:00" /> : undefined}
        />
      </Card>

      {/* Network */}
      <SectionTitle>МЕРЕЖА</SectionTitle>
      <Card>
        <TextInput label="IP Сервера" value={config.serverIP} onChange={(v) => update('serverIP', v)} placeholder="192.168.1.xxx" />
        <TextInput label="Порт сервера" value={config.serverPort} onChange={(v) => update('serverPort', v)} />
        <TextInput label="MQTT Сервер IP" value={config.mqttIP} onChange={(v) => update('mqttIP', v)} />
        <TextInput label="MQTT Порт" value={config.mqttPort} onChange={(v) => update('mqttPort', v)} />
        <TextInput label="Назва WiFi мережі" value={config.wifiName} onChange={(v) => update('wifiName', v)} placeholder="MyFarm_WiFi" />
        <ToggleRow label="Авто-перепідключення" checked={config.autoReconnect} onChange={(v) => update('autoReconnect', v)} />
        <ToggleRow label="MQTT Брокер" checked={config.mqttBroker} onChange={(v) => update('mqttBroker', v)} />
      </Card>

      {/* Language */}
      <SectionTitle>НАЛАШТУВАННЯ МОВИ</SectionTitle>
      <Card>
        <label className="mb-1.5 block text-xs text-muted-foreground">Мова</label>
        <div className="mb-3">
          <SegButtons
            options={[
              { label: '🇺🇦 Українська', value: 'ua' },
              { label: '🇬🇧 English', value: 'en' },
            ]}
            value={config.language}
            onChange={(v) => update('language', v)}
          />
        </div>
        <label className="mb-1.5 block text-xs text-muted-foreground">Мова журналу</label>
        <SegButtons
          options={[
            { label: 'ТЕХНІЧНА', value: 'tech' },
            { label: 'ЛОКАЛІЗОВАНА', value: 'local' },
          ]}
          value={config.logLanguage}
          onChange={(v) => update('logLanguage', v)}
        />
      </Card>

      {/* System config */}
      <SectionTitle>КОНФІГУРАЦІЯ СИСТЕМИ</SectionTitle>
      <Card>
        <label className="mb-1.5 block text-xs text-muted-foreground">Зберігання логів</label>
        <div className="mb-3">
          <SegButtons
            options={[
              { label: '7d', value: '7d' },
              { label: '14d', value: '14d' },
              { label: '30d', value: '30d' },
              { label: '90d', value: '90d' },
            ]}
            value={config.logRetention}
            onChange={(v) => update('logRetention', v)}
          />
        </div>
        <label className="mb-1.5 block text-xs text-muted-foreground">Частота опитування</label>
        <div className="mb-3">
          <SegButtons
            options={[
              { label: '1s', value: '1s' },
              { label: '5s', value: '5s' },
              { label: '10s', value: '10s' },
              { label: '30s', value: '30s' },
            ]}
            value={config.pollInterval}
            onChange={(v) => update('pollInterval', v)}
          />
        </div>
        <ToggleRow label="Звук сповіщень" checked={config.soundAlerts} onChange={(v) => update('soundAlerts', v)} />
        <ToggleRow label="Вібрація" checked={config.vibration} onChange={(v) => update('vibration', v)} />
      </Card>

      {/* Security */}
      <SectionTitle>БЕЗПЕКА</SectionTitle>
      <SecuritySection config={config} update={update} />

      {/* Coming soon */}
      <SectionTitle>НЕЗАБАРОМ</SectionTitle>
      <div className="grid grid-cols-2 gap-2">
        {[
          { icon: Zap, label: 'Сонячний інвертор' },
          { icon: Battery, label: 'Акумулятори' },
          { icon: FlaskRound, label: 'pH автодозування' },
          { icon: AppWindow, label: 'Актуатор вікна' },
          { icon: Camera, label: 'Відеоспостереження' },
          { icon: Lightbulb, label: 'Розумне освітлення' },
        ].map((c) => {
          const Icon = c.icon
          return (
            <button
              key={c.label}
              onClick={() => setSoonModal(c.label)}
              className="relative flex flex-col items-center gap-2 rounded-xl border bg-card p-4 opacity-70 transition-all active:scale-95"
            >
              <Lock size={12} className="absolute right-2 top-2 text-muted-foreground" />
              <Icon size={22} className="text-muted-foreground" />
              <span className="text-center text-[11px] text-muted-foreground">{c.label}</span>
            </button>
          )
        })}
      </div>

      {/* Themes */}
      <SectionTitle>ТЕМИ</SectionTitle>
      <div className="grid grid-cols-3 gap-2">
        {[
          { id: 'cyber_dark', label: 'Cyber Dark', bg: '#0a0a0f', accent: '#00FFFF' },
          { id: 'amoled', label: 'AMOLED Black', bg: '#000000', accent: '#00FF88' },
          { id: 'light', label: 'Clean Light', bg: '#f4f5fa', accent: '#0891b2' },
        ].map((t) => {
          const active = config.theme === t.id
          return (
            <button
              key={t.id}
              onClick={() => update('theme', t.id)}
              className="rounded-xl border p-3 text-center transition-all"
              style={{ borderColor: active ? 'var(--cyan)' : 'var(--border)', borderWidth: active ? 2 : 1 }}
            >
              <div
                className="mx-auto mb-2 h-10 w-full rounded-md border"
                style={{ backgroundColor: t.bg, borderColor: t.accent }}
              >
                <div className="m-1.5 h-1.5 w-1/2 rounded-full" style={{ backgroundColor: t.accent }} />
              </div>
              <span className="text-[10px]">
                {t.label} {active && '✓'}
              </span>
            </button>
          )
        })}
      </div>

      <footer className="mt-6 px-1 text-center font-mono text-[10px] text-muted-foreground">
        AutoFarm OS v2.4.1 | Build 20240615 | Uptime: 14d 6h
      </footer>

      {/* Profile edit modal */}
      <Modal open={editProfile} onClose={() => setEditProfile(false)} title="Редагувати профіль">
        <TextInput label="Ім'я" value={config.adminName} onChange={(v) => update('adminName', v)} />
        <TextInput label="Роль" value={config.adminRole} onChange={(v) => update('adminRole', v)} />
        <Btn variant="cyan" className="w-full" onClick={() => setEditProfile(false)}>
          ЗБЕРЕГТИ
        </Btn>
      </Modal>

      {/* Coming soon modal */}
      <Modal open={!!soonModal} onClose={() => setSoonModal(null)} title={soonModal ?? ''}>
        <p className="py-2 text-center text-sm text-muted-foreground">
          Доступно після підключення обладнання
        </p>
      </Modal>
    </div>
  )
}

function ToggleRow({
  label,
  checked,
  onChange,
  extra,
}: {
  label: string
  checked: boolean
  onChange: (v: boolean) => void
  extra?: React.ReactNode
}) {
  return (
    <div className="flex items-center justify-between border-t py-2.5 first:border-t-0">
      <span className="text-sm">{label}</span>
      <div className="flex items-center gap-2">
        {extra}
        <Toggle checked={checked} onChange={onChange} />
      </div>
    </div>
  )
}

function LockedRow({ label }: { label: string }) {
  return (
    <div className="flex items-center justify-between border-t py-2.5 first:border-t-0">
      <span className="text-sm">{label}</span>
      <span className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
        <Lock size={11} /> завжди увімкнено
      </span>
    </div>
  )
}

function TimePill({ time }: { time: string }) {
  return (
    <span className="rounded-md border bg-[var(--background)] px-2 py-1 font-mono text-[11px] text-[var(--cyan)]">
      {time}
    </span>
  )
}
