'use client'

import { useState } from 'react'
import {
  Card,
  SectionTitle,
  Btn,
  TextInput,
  StatusDot,
  Modal,
  SegButtons,
  Toggle,
} from '@/components/ui-kit'
import type { PageProps } from './types'
import type { Config } from '@/lib/config'
import {
  Server,
  ChevronDown,
  Copy,
  Check,
  Zap,
  RefreshCw,
  Wifi,
  Cpu,
} from 'lucide-react'

export function EquipmentPage({ config, update }: PageProps) {
  const [serverToken, setServerToken] = useState('')
  const [modal, setModal] = useState<{ title: string; body: React.ReactNode } | null>(null)
  const [esp32Open, setEsp32Open] = useState(false)
  const [arduinoOpen, setArduinoOpen] = useState(false)
  const [gpioOpen, setGpioOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const [checking, setChecking] = useState(false)

  const endpoint = `http://${config.serverIP || '0.0.0.0'}:${config.serverPort}/api/hardware/update`

  const copyEndpoint = () => {
    navigator.clipboard?.writeText(endpoint)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const checkConnection = () => {
    setChecking(true)
    setTimeout(() => {
      setChecking(false)
      setModal({
        title: 'Перевірка підключення',
        body: config.serverIP ? (
          <div className="text-sm">
            <p className="mb-2 font-semibold text-[var(--green)]">● Підключення успішне</p>
            <p className="font-mono text-xs text-muted-foreground">PING {config.serverIP} → 12ms</p>
            <p className="font-mono text-xs text-muted-foreground">HTTP 200 OK · v2.4.1</p>
            <p className="font-mono text-xs text-muted-foreground">Датчиків онлайн: 12</p>
          </div>
        ) : (
          <p className="text-sm text-[var(--red)]">○ Сервер не налаштовано. Введіть IP адресу.</p>
        ),
      })
    }, 1400)
  }

  return (
    <div>
      <header className="mb-4 px-1">
        <h1 className="text-xl font-bold tracking-tight">Обладнання</h1>
        <p className="text-xs text-muted-foreground">Вузли ESP32 · сервер · калібрування</p>
      </header>

      <SectionTitle>ПІДКЛЮЧЕННЯ ДО СЕРВЕРА</SectionTitle>
      <Card accent={config.serverIP ? 'var(--green)' : 'var(--orange)'}>
        <div className="mb-3 flex items-center gap-2">
          <Server size={16} color="var(--cyan)" />
          <span className="text-sm font-semibold">🔌 Адреса Сервера</span>
        </div>
        {!config.serverIP && (
          <div className="mb-3 rounded-lg bg-[var(--orange)]/10 px-3 py-2 text-xs font-medium text-[var(--orange)]">
            ⚠️ Сервер не налаштовано
          </div>
        )}
        <TextInput
          label="IP адреса сервера"
          value={config.serverIP}
          onChange={(v) => update('serverIP', v)}
          placeholder="192.168.1.xxx"
        />
        <TextInput
          label="Порт"
          value={config.serverPort}
          onChange={(v) => update('serverPort', v)}
          placeholder="3000"
        />
        <TextInput label="API Token" value={serverToken} onChange={setServerToken} password placeholder="••••••••" />
        <Btn variant="cyan" className="w-full" onClick={checkConnection}>
          {checking ? 'ПЕРЕВІРКА...' : 'ПЕРЕВІРИТИ ПІДКЛЮЧЕННЯ'}
        </Btn>
        <div className="mt-3 flex items-center gap-2 text-xs">
          {config.serverIP ? (
            <span className="font-semibold text-[var(--green)]">● Налаштовано</span>
          ) : (
            <span className="text-muted-foreground">○ Не налаштовано</span>
          )}
        </div>
      </Card>

      <SectionTitle>ІНТЕГРАЦІЯ ESP32</SectionTitle>
      <Card>
        <button
          className="flex w-full items-center justify-between"
          onClick={() => setEsp32Open((o) => !o)}
        >
          <span className="flex items-center gap-2 text-sm font-semibold">
            <Cpu size={16} color="var(--cyan)" /> Endpoint для прошивки
          </span>
          <ChevronDown
            size={18}
            className="text-muted-foreground transition-transform"
            style={{ transform: esp32Open ? 'rotate(180deg)' : 'none' }}
          />
        </button>
        {esp32Open && (
          <div className="mt-3 animate-fade-in">
            <div className="mb-2 flex items-center gap-2 rounded-lg border bg-[var(--background)] p-2.5">
              <code className="flex-1 break-all font-mono text-[11px] text-[var(--green)]">
                {endpoint}
              </code>
              <button onClick={copyEndpoint} className="shrink-0 text-muted-foreground">
                {copied ? <Check size={15} color="var(--green)" /> : <Copy size={15} />}
              </button>
            </div>
            <p className="mb-1 text-[10px] uppercase tracking-wide text-muted-foreground">
              Приклад JSON
            </p>
            <pre className="overflow-x-auto rounded-lg border bg-[var(--background)] p-3 font-mono text-[10px] leading-relaxed text-foreground/80">
{`{
  "node": "A",
  "waterTemp": 27.5,
  "oxygen": 7.1,
  "pH": 7.8
}`}
            </pre>
            <button
              className="mt-2 flex w-full items-center justify-between text-xs text-muted-foreground"
              onClick={() => setArduinoOpen((o) => !o)}
            >
              <span>Шаблон коду Arduino</span>
              <ChevronDown
                size={14}
                style={{ transform: arduinoOpen ? 'rotate(180deg)' : 'none' }}
              />
            </button>
            {arduinoOpen && (
              <pre className="mt-2 animate-fade-in overflow-x-auto rounded-lg border bg-[var(--background)] p-3 font-mono text-[10px] leading-relaxed text-[var(--cyan)]/90">
{`#include <WiFi.h>
#include <HTTPClient.h>

void sendData() {
  HTTPClient http;
  http.begin("${endpoint}");
  http.addHeader("Content-Type",
    "application/json");
  String body = "{\\"node\\":\\"A\\","
    "\\"waterTemp\\":27.5}";
  http.POST(body);
  http.end();
}`}
              </pre>
            )}
          </div>
        )}
      </Card>

      {/* Node stats */}
      <div className="mt-3 grid grid-cols-3 gap-2">
        {[
          { v: '2', l: 'Активні', c: 'var(--green)' },
          { v: '12', l: 'Датчиків', c: 'var(--cyan)' },
          { v: '0', l: 'Попереджень', c: 'var(--muted-foreground)' },
        ].map((s) => (
          <div key={s.l} className="rounded-lg border bg-card p-2.5 text-center">
            <div className="font-mono text-base font-bold" style={{ color: s.c }}>
              {s.v}
            </div>
            <div className="mt-0.5 text-[9px] uppercase tracking-wide text-muted-foreground">
              {s.l}
            </div>
          </div>
        ))}
      </div>

      <SectionTitle>ВУЗЛИ ESP32</SectionTitle>
      <div className="flex flex-col gap-3">
        <NodeCard
          name="NODE A"
          role="Контролер Басейнів"
          online
          ipKey="nodeA_IP"
          ip={config.nodeA_IP}
          update={update}
          signal="-42 dBm"
          uptime="14d 6h"
          metrics={[
            { l: 'ТЕМП.ВОДИ', v: `${config.waterTemp.toFixed(1)}°` },
            { l: 'КИСЕНЬ', v: config.oxygen.toFixed(1) },
            { l: 'pH', v: config.pH.toFixed(1) },
          ]}
          setModal={setModal}
        />
        <NodeCard
          name="NODE B"
          role="Контролер Клімату"
          online
          ipKey="nodeB_IP"
          ip={config.nodeB_IP}
          update={update}
          signal="-51 dBm"
          uptime="9d 2h"
          metrics={[
            { l: 'ТЕМП.ПОВІТРЯ', v: `${config.airTemp.toFixed(1)}°` },
            { l: 'ВОЛОГІСТЬ', v: `${config.humidity.toFixed(0)}%` },
            { l: 'АМІАК', v: config.ammonia.toFixed(3) },
          ]}
          setModal={setModal}
        />
        <NodeCard
          name="NODE C"
          role="Контролер Освітлення"
          online={false}
          ipKey="nodeC_IP"
          ip={config.nodeC_IP}
          update={update}
          metrics={[]}
          setModal={setModal}
        />
      </div>

      <SectionTitle>КАЛІБРУВАННЯ ДАТЧИКІВ</SectionTitle>
      <CalibrationCard config={config} update={update} setModal={setModal} />

      <SectionTitle>КАРТА ВИВОДІВ GPIO</SectionTitle>
      <Card>
        <button
          className="flex w-full items-center justify-between"
          onClick={() => setGpioOpen((o) => !o)}
        >
          <span className="text-sm font-semibold">Реле 8 каналів</span>
          <ChevronDown
            size={18}
            className="text-muted-foreground transition-transform"
            style={{ transform: gpioOpen ? 'rotate(180deg)' : 'none' }}
          />
        </button>
        {gpioOpen && <GpioTable />}
      </Card>

      <Modal open={!!modal} onClose={() => setModal(null)} title={modal?.title}>
        {modal?.body}
      </Modal>
    </div>
  )
}

function NodeCard({
  name,
  role,
  online,
  ip,
  ipKey,
  update,
  signal,
  uptime,
  metrics,
  setModal,
}: {
  name: string
  role: string
  online: boolean
  ip: string
  ipKey: 'nodeA_IP' | 'nodeB_IP' | 'nodeC_IP'
  update: PageProps['update']
  signal?: string
  uptime?: string
  metrics: { l: string; v: string }[]
  setModal: (m: { title: string; body: React.ReactNode } | null) => void
}) {
  const [connecting, setConnecting] = useState(false)
  const color = online ? 'var(--green)' : 'var(--red)'

  const ping = () =>
    setModal({ title: `Пінг ${name}`, body: <p className="text-sm">Відповідь: <span className="font-mono text-[var(--green)]">12ms ✓</span></p> })

  const reboot = () =>
    setModal({
      title: `Перезавантаження ${name}`,
      body: (
        <div className="text-sm">
          <p className="mb-2">Підтвердити перезавантаження вузла?</p>
          <p className="font-mono text-xs text-[var(--orange)]">Перезавантаження... вузол буде офлайн ~15с</p>
        </div>
      ),
    })

  const connect = () => {
    setConnecting(true)
    setTimeout(() => {
      setConnecting(false)
      setModal({
        title: `Підключення ${name}`,
        body: <p className="text-sm text-[var(--red)]">Не вдалося підключитися. Перевірте живлення вузла.</p>,
      })
    }, 1800)
  }

  return (
    <Card accent={color}>
      <div className="mb-2 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm font-bold">{name}</span>
            <span
              className="flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold"
              style={{ backgroundColor: color + '22', color }}
            >
              <StatusDot color={color} pulse={online} />
              {online ? 'ONLINE' : 'OFFLINE'}
            </span>
          </div>
          <p className="mt-0.5 text-xs text-muted-foreground">{role}</p>
        </div>
        {online && (
          <div className="text-right text-[10px] text-muted-foreground">
            <div className="flex items-center gap-1">
              <Wifi size={11} /> {signal}
            </div>
            <div>uptime {uptime}</div>
          </div>
        )}
      </div>

      <div className="mb-2">
        <label className="mb-1 block text-[10px] uppercase tracking-wide text-muted-foreground">
          IP адреса
        </label>
        <input
          value={ip}
          onChange={(e) => update(ipKey, e.target.value)}
          className="w-full rounded-lg border bg-[var(--background)] px-2.5 py-1.5 font-mono text-xs outline-none focus:border-[var(--cyan)]"
        />
      </div>

      {online && metrics.length > 0 && (
        <div className="mb-3 grid grid-cols-3 gap-1.5">
          {metrics.map((m) => (
            <div key={m.l} className="rounded-md border bg-[var(--background)] p-1.5 text-center">
              <div className="font-mono text-xs font-bold text-[var(--cyan)]">{m.v}</div>
              <div className="text-[8px] uppercase text-muted-foreground">{m.l}</div>
            </div>
          ))}
        </div>
      )}

      {!online && (
        <p className="mb-3 font-mono text-xs text-[var(--red)]">ОФЛАЙН: 2г 14хв тому</p>
      )}

      {online ? (
        <div className="flex gap-2">
          <Btn variant="outline" className="flex-1 !py-2 !text-xs" onClick={ping}>
            <span className="flex items-center justify-center gap-1">
              <Zap size={13} /> ПІНГ
            </span>
          </Btn>
          <Btn variant="outline" className="flex-1 !py-2 !text-xs" onClick={reboot}>
            <span className="flex items-center justify-center gap-1">
              <RefreshCw size={13} /> ПЕРЕЗАВАНТ.
            </span>
          </Btn>
        </div>
      ) : (
        <Btn variant="cyan" className="w-full !py-2 !text-xs" onClick={connect}>
          {connecting ? '📡 ПІДКЛЮЧЕННЯ...' : '📡 ПІДКЛЮЧИТИСЬ'}
        </Btn>
      )}
    </Card>
  )
}

function CalibrationCard({
  config,
  update,
  setModal,
}: {
  config: Config
  update: PageProps['update']
  setModal: (m: { title: string; body: React.ReactNode } | null) => void
}) {
  const [tab, setTab] = useState<'temp' | 'o2' | 'ph'>('temp')

  const defs = {
    temp: { key: 'tempOffset' as const, min: -2, max: 2, step: 0.1, unit: '°C', raw: 27.3 },
    o2: { key: 'o2Offset' as const, min: -1, max: 1, step: 0.1, unit: 'mg/L', raw: 7.0 },
    ph: { key: 'phOffset' as const, min: -0.5, max: 0.5, step: 0.05, unit: 'pH', raw: 7.6 },
  }
  const d = defs[tab]
  const offset = config[d.key]

  return (
    <Card>
      <div className="mb-3">
        <SegButtons
          options={[
            { label: 'ТЕМПЕРАТУРА', value: 'temp' },
            { label: 'КИСЕНЬ', value: 'o2' },
            { label: 'pH', value: 'ph' },
          ]}
          value={tab}
          onChange={(v) => setTab(v as typeof tab)}
        />
      </div>

      <label className="mb-1 block text-xs text-muted-foreground">Зміщення датчика (offset)</label>
      <input
        type="range"
        min={d.min}
        max={d.max}
        step={d.step}
        value={offset}
        onChange={(e) => update(d.key, Number(e.target.value))}
        className="mb-2"
      />
      <p className="mb-2 font-mono text-sm text-[var(--cyan)]">
        {offset > 0 ? '+' : ''}
        {offset.toFixed(2)} {d.unit} offset
      </p>
      <div className="mb-3 rounded-lg border bg-[var(--background)] p-2.5 font-mono text-xs">
        <span className="text-muted-foreground">Сирі дані: {d.raw}{d.unit} → </span>
        <span className="text-[var(--green)]">Скориговані: {(d.raw + offset).toFixed(2)}{d.unit}</span>
      </div>
      <div className="flex gap-2">
        <Btn variant="outline" className="flex-1 !py-2 !text-xs" onClick={() => update(d.key, 0)}>
          СКИНУТИ ДО 0
        </Btn>
        <Btn
          variant="cyan"
          className="flex-1 !py-2 !text-xs"
          onClick={() =>
            setModal({
              title: 'Калібрування',
              body: <p className="text-sm text-[var(--green)]">✅ Калібрування збережено</p>,
            })
          }
        >
          ЗБЕРЕГТИ
        </Btn>
      </div>
    </Card>
  )
}

const GPIO_PINS = [
  { in: 'IN1', gpio: 'GPIO 19', label: 'Освітлення басейнів', on: false },
  { in: 'IN2', gpio: 'GPIO 18', label: 'Приплив вентиляції', on: true },
  { in: 'IN3', gpio: 'GPIO 17', label: 'Витяжка вентиляції', on: true },
  { in: 'IN4', gpio: 'GPIO 16', label: 'Аерація Басейн 1', on: true },
  { in: 'IN5', gpio: 'GPIO 15', label: 'Аерація Басейн 2', on: true },
  { in: 'IN6', gpio: 'GPIO 14', label: 'Аерація Басейн 3', on: true },
  { in: 'IN7', gpio: 'GPIO 13', label: 'Годівниця', on: false },
  { in: 'IN8', gpio: 'GPIO 12', label: 'Резерв', on: false },
]

function GpioTable() {
  const [pins, setPins] = useState(GPIO_PINS)
  return (
    <div className="mt-3 animate-fade-in flex flex-col gap-1.5">
      {pins.map((p, i) => (
        <div key={p.in} className="flex items-center justify-between rounded-lg border bg-[var(--background)] px-2.5 py-2">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-mono text-xs font-bold text-[var(--cyan)]">{p.in}</span>
              <span className="font-mono text-[10px] text-muted-foreground">{p.gpio}</span>
            </div>
            <p className="truncate text-xs text-foreground/80">{p.label}</p>
          </div>
          <Toggle
            checked={p.on}
            onChange={(v) =>
              setPins((prev) => prev.map((x, xi) => (xi === i ? { ...x, on: v } : x)))
            }
          />
        </div>
      ))}
    </div>
  )
}
