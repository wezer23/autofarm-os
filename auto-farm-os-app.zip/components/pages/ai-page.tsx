'use client'

import { useEffect, useState } from 'react'
import { Card, SectionTitle, Toggle, Btn, Modal } from '@/components/ui-kit'
import { SensorGrid } from '@/components/sensor-grid'
import { TerminalLog } from '@/components/terminal-log'
import { MiniLineChart } from '@/components/mini-chart'
import type { PageProps } from './types'
import { Brain, FlaskConical, GraduationCap, FileText } from 'lucide-react'

const MODE_DESC: Record<string, string> = {
  РУЧНИЙ: 'ШІ лише спостерігає. Усі рішення приймає оператор вручну.',
  АСИСТОВАНИЙ: 'ШІ пропонує дії та чекає підтвердження оператора перед виконанням.',
  АВТОНОМНИЙ: 'ШІ самостійно керує обладнанням у межах безпечних порогів.',
}

const DIAG_STEPS = [
  'Ініціалізація нейронного ядра...',
  'Перевірка датчиків (12/12)...',
  'Тест реле GPIO...',
  'Симуляція аварійного сценарію...',
  'Діагностика завершена ✓',
]

function genPrediction() {
  return Array.from({ length: 19 }, (_, i) => {
    const day = i * 5
    return {
      d: `${day}д`,
      biomass: +(40 + day * 0.55 + Math.sin(day / 12) * 2).toFixed(1),
      molting: +(20 + Math.sin(day / 8) * 18 + Math.random() * 6).toFixed(0),
    }
  })
}

export function AIPage({ config, update }: PageProps) {
  const [diagOpen, setDiagOpen] = useState(false)
  const [diagStep, setDiagStep] = useState(0)
  const [trainOpen, setTrainOpen] = useState(false)
  const [reportOpen, setReportOpen] = useState(false)
  const [prediction] = useState(genPrediction)

  useEffect(() => {
    if (!diagOpen) return
    setDiagStep(0)
    const id = setInterval(() => {
      setDiagStep((s) => {
        if (s >= DIAG_STEPS.length - 1) {
          clearInterval(id)
          return s
        }
        return s + 1
      })
    }, 900)
    return () => clearInterval(id)
  }, [diagOpen])

  const protocols: { key: keyof typeof config; label: string }[] = [
    { key: 'proto_o2', label: '💨 Контроль кисню (O₂)' },
    { key: 'proto_thermal', label: '🌡️ Термальний протокол' },
    { key: 'proto_feeding', label: '🍽️ Розумне годування' },
    { key: 'proto_molting', label: '🦞 Прогноз линяння' },
    { key: 'proto_humidity', label: '💧 Контроль вологості' },
    { key: 'proto_growth', label: '📈 Аналіз росту' },
  ]

  return (
    <div>
      <header className="mb-4 px-1">
        <h1 className="text-xl font-bold tracking-tight">ШІ Ядро</h1>
        <p className="text-xs text-muted-foreground">Нейронний двигун · протоколи · прогнози</p>
      </header>

      {/* Header purple gradient */}
      <div
        className="rounded-xl border p-4"
        style={{
          background: 'linear-gradient(135deg, var(--purple) 0%, #5b3ba8 100%)',
          borderColor: 'var(--purple)',
        }}
      >
        <div className="flex items-center gap-3">
          <Brain size={28} color="#fff" />
          <div>
            <p className="text-sm font-bold text-white">🧠 ШІ ЯДРО – НЕЙРОННИЙ ДВИГУН v2.4</p>
            <p className="font-mono text-[11px] text-white/80">
              Uptime: 14д 6г · Model: AutoFarm-NLP-v4
            </p>
          </div>
        </div>
      </div>

      <SectionTitle>РЕЖИМ РОБОТИ ШІ</SectionTitle>
      <Card>
        <div className="mb-3 flex gap-2">
          {['РУЧНИЙ', 'АСИСТОВАНИЙ', 'АВТОНОМНИЙ'].map((m) => {
            const active = config.aiMode === m
            return (
              <button
                key={m}
                onClick={() => update('aiMode', m)}
                className="flex-1 rounded-lg px-2 py-2.5 text-[11px] font-semibold transition-all"
                style={
                  active
                    ? { backgroundColor: 'var(--purple)', color: '#fff' }
                    : { border: '1px solid var(--border)', color: 'var(--muted-foreground)' }
                }
              >
                {m}
              </button>
            )
          })}
        </div>
        <p className="text-xs text-muted-foreground">{MODE_DESC[config.aiMode]}</p>
      </Card>

      <SectionTitle>СТАН ДАТЧИКІВ</SectionTitle>
      <SensorGrid config={config} />

      <SectionTitle>НЕЙРОННІ ПРОТОКОЛИ</SectionTitle>
      <Card>
        <div className="flex flex-col gap-1">
          {protocols.map((p, i) => (
            <div
              key={p.key}
              className={`flex items-center justify-between py-2.5 ${i > 0 ? 'border-t' : ''}`}
            >
              <span className="text-sm">{p.label}</span>
              <Toggle
                color="var(--purple)"
                checked={config[p.key] as boolean}
                onChange={(v) => update(p.key as 'proto_o2', v)}
              />
            </div>
          ))}
        </div>
      </Card>

      <SectionTitle>ПОРОГОВІ ЗНАЧЕННЯ</SectionTitle>
      <Card>
        <div className="mb-1 flex items-center justify-between">
          <span className="text-xs uppercase tracking-wide text-muted-foreground">O₂ мінімум</span>
          <span className="font-mono text-sm font-semibold text-[var(--cyan)]">
            {config.o2Min.toFixed(1)} mg/L
          </span>
        </div>
        <input
          type="range"
          min={3}
          max={7}
          step={0.1}
          value={config.o2Min}
          onChange={(e) => update('o2Min', Number(e.target.value))}
          className="mb-1.5"
        />
        <p className="mb-4 font-mono text-[11px] text-muted-foreground">
          Поточне: {config.oxygen.toFixed(1)} · поріг: {config.o2Min.toFixed(1)}
        </p>

        <div className="mb-1 flex items-center justify-between">
          <span className="text-xs uppercase tracking-wide text-muted-foreground">
            Темп. максимум
          </span>
          <span className="font-mono text-sm font-semibold text-[var(--cyan)]">
            {config.tempMax.toFixed(1)} °C
          </span>
        </div>
        <input
          type="range"
          min={28}
          max={32}
          step={0.1}
          value={config.tempMax}
          onChange={(e) => update('tempMax', Number(e.target.value))}
          className="mb-1.5"
        />
        <p className="font-mono text-[11px] text-muted-foreground">
          Поточне: {config.waterTemp.toFixed(1)} · поріг: {config.tempMax.toFixed(1)}
        </p>
      </Card>

      <div className="mt-3">
        <Btn variant="redOutline" className="w-full" onClick={() => setDiagOpen(true)}>
          <span className="flex items-center justify-center gap-2">
            <FlaskConical size={15} /> ТЕСТ УПРАВЛІННЯ
          </span>
        </Btn>
      </div>

      <SectionTitle>ЖУРНАЛ АКТИВНОСТІ ШІ</SectionTitle>
      <Card>
        <TerminalLog height="h-44" />
      </Card>

      <SectionTitle>ПРОГНОЗИ (90 ДНІВ)</SectionTitle>
      <Card>
        <p className="mb-2 text-[10px] uppercase tracking-wide text-muted-foreground">
          Біомаса (кг) та ймовірність линяння (%)
        </p>
        <MiniLineChart
          data={prediction}
          xKey="d"
          dataKeys={[
            { key: 'biomass', color: 'var(--green)', name: 'Біомаса кг' },
            { key: 'molting', color: 'var(--purple)', name: 'Линяння %' },
          ]}
          height={190}
        />
      </Card>

      <div className="mt-3 flex gap-2">
        <Btn variant="purple" className="flex-1" onClick={() => setTrainOpen(true)}>
          <span className="flex items-center justify-center gap-1.5">
            <GraduationCap size={15} /> НАВЧИТИ ШІ
          </span>
        </Btn>
        <Btn variant="outline" className="flex-1" onClick={() => setReportOpen(true)}>
          <span className="flex items-center justify-center gap-1.5">
            <FileText size={15} /> ЗВІТ ТИЖНЯ
          </span>
        </Btn>
      </div>

      {/* Diagnostic modal */}
      <Modal open={diagOpen} onClose={() => setDiagOpen(false)} title="Тест управління">
        <div className="flex flex-col gap-2">
          {DIAG_STEPS.map((step, i) => {
            const done = i < diagStep
            const cur = i === diagStep
            return (
              <div
                key={i}
                className="flex items-center gap-3 rounded-lg border bg-[var(--background)] px-3 py-2.5"
                style={{ opacity: i <= diagStep ? 1 : 0.35 }}
              >
                <span
                  className="flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold"
                  style={{
                    backgroundColor: done ? 'var(--green)' : cur ? 'var(--purple)' : 'var(--border)',
                    color: '#fff',
                  }}
                >
                  {done ? '✓' : i + 1}
                </span>
                <span className="font-mono text-xs">{step}</span>
              </div>
            )
          })}
        </div>
      </Modal>

      {/* Training modal */}
      <Modal open={trainOpen} onClose={() => setTrainOpen(false)} title="Навчання ШІ">
        <div className="text-sm">
          <p className="mb-3 text-muted-foreground">
            Модель буде донавчена на історичних даних ферми за останні 90 днів.
          </p>
          <div className="mb-3 rounded-lg border bg-[var(--background)] p-3 font-mono text-xs">
            <p className="text-muted-foreground">Записів: 12 480</p>
            <p className="text-muted-foreground">Епох: 50</p>
            <p className="text-[var(--green)]">Точність базової моделі: 94.2%</p>
          </div>
          <Btn variant="purple" className="w-full" onClick={() => setTrainOpen(false)}>
            ЗАПУСТИТИ НАВЧАННЯ
          </Btn>
        </div>
      </Modal>

      {/* Weekly report modal */}
      <Modal open={reportOpen} onClose={() => setReportOpen(false)} title="Звіт за тиждень">
        <div className="flex flex-col gap-2 text-sm">
          {[
            { l: 'Середня температура', v: '27.8°C', c: 'var(--green)' },
            { l: 'Середній O₂', v: '7.0 mg/L', c: 'var(--green)' },
            { l: 'Приріст біомаси', v: '+2.4 кг', c: 'var(--cyan)' },
            { l: 'Линянь зафіксовано', v: '6', c: 'var(--purple)' },
            { l: 'Годувань', v: '21', c: 'var(--cyan)' },
            { l: 'Тривог', v: '0', c: 'var(--green)' },
          ].map((r) => (
            <div
              key={r.l}
              className="flex items-center justify-between rounded-lg border bg-[var(--background)] px-3 py-2.5"
            >
              <span className="text-muted-foreground">{r.l}</span>
              <span className="font-mono font-semibold" style={{ color: r.c }}>
                {r.v}
              </span>
            </div>
          ))}
        </div>
      </Modal>
    </div>
  )
}
