'use client'

import { useState } from 'react'
import { Card, Btn, Toggle, Modal, SegButtons } from '@/components/ui-kit'
import type { PageProps } from '../types'
import { ShieldCheck, KeyRound, ScrollText, Lock } from 'lucide-react'

export function SecuritySection({ config, update }: PageProps) {
  const [pinModal, setPinModal] = useState(false)
  const [pin, setPin] = useState('')
  const [pin2, setPin2] = useState('')
  const [logModal, setLogModal] = useState(false)
  const [lockModal, setLockModal] = useState(false)
  const [pinSaved, setPinSaved] = useState(false)

  const openPinSetup = (enable: boolean) => {
    if (enable) {
      setPin('')
      setPin2('')
      setPinSaved(false)
      setPinModal(true)
    } else {
      update('pinEnabled', false)
    }
  }

  const savePin = () => {
    if (pin.length === 6 && pin === pin2) {
      update('pinEnabled', true)
      setPinSaved(true)
      setTimeout(() => setPinModal(false), 1200)
    }
  }

  return (
    <Card>
      {/* status card */}
      <div className="mb-3 rounded-lg border bg-[var(--background)] p-3">
        <div className="mb-2 flex items-center gap-2">
          <ShieldCheck size={16} color="var(--green)" />
          <span className="text-sm font-semibold">🔒 БЕЗПЕКА СИСТЕМИ</span>
        </div>
        <p className="text-xs text-[var(--green)]">Статус: ● ЗАХИЩЕНО</p>
        <p className="text-xs text-muted-foreground">Активні сесії: 1</p>
        <p className="text-xs text-muted-foreground">Спроби входу (24г): 0 ✓</p>
        <div className="mt-2 flex items-center gap-2">
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-[var(--border)]">
            <div className="h-full rounded-full bg-[var(--green)]" style={{ width: '94%' }} />
          </div>
          <span className="font-mono text-xs text-[var(--green)]">94/100</span>
        </div>
      </div>

      <div className="flex items-center justify-between py-2.5">
        <span className="text-sm">PIN захист</span>
        <Toggle checked={config.pinEnabled} onChange={openPinSetup} />
      </div>
      <div className="flex items-center justify-between border-t py-2.5">
        <span className="text-sm">Двофакторна автентифікація (2FA)</span>
        <Toggle
          checked={config.twoFactorEnabled}
          onChange={(v) => update('twoFactorEnabled', v)}
        />
      </div>
      <div className="border-t py-2.5">
        <p className="mb-2 text-sm">Автоблок через:</p>
        <SegButtons
          options={[
            { label: '1хв', value: 1 },
            { label: '5хв', value: 5 },
            { label: '15хв', value: 15 },
            { label: 'ніколи', value: 0 },
          ]}
          value={config.sessionTimeout}
          onChange={(v) => update('sessionTimeout', v)}
        />
      </div>

      <div className="mt-2 flex flex-col gap-2">
        <Btn variant="outline" className="w-full !text-xs" onClick={() => openPinSetup(true)}>
          <span className="flex items-center justify-center gap-1.5">
            <KeyRound size={14} /> ЗМІНИТИ PIN
          </span>
        </Btn>
        <Btn variant="outline" className="w-full !text-xs" onClick={() => setLogModal(true)}>
          <span className="flex items-center justify-center gap-1.5">
            <ScrollText size={14} /> ЖУРНАЛ БЕЗПЕКИ
          </span>
        </Btn>
        <Btn variant="redOutline" className="w-full !text-xs" onClick={() => setLockModal(true)}>
          <span className="flex items-center justify-center gap-1.5">
            <Lock size={14} /> LOCKDOWN
          </span>
        </Btn>
      </div>

      {/* PIN setup modal */}
      <Modal open={pinModal} onClose={() => setPinModal(false)} title="Налаштування PIN">
        {pinSaved ? (
          <p className="py-4 text-center text-sm font-semibold text-[var(--green)]">
            ✅ PIN збережено
          </p>
        ) : (
          <div>
            <PinInput label="Введіть новий PIN (6 цифр)" value={pin} onChange={setPin} />
            <PinInput label="Підтвердіть PIN" value={pin2} onChange={setPin2} />
            {pin2.length === 6 && pin !== pin2 && (
              <p className="mb-2 text-xs text-[var(--red)]">PIN не співпадають</p>
            )}
            <Btn
              variant="cyan"
              className="w-full"
              disabled={pin.length !== 6 || pin !== pin2}
              onClick={savePin}
            >
              ЗБЕРЕГТИ
            </Btn>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">
              PIN буде надіслано для підтвердження через Telegram
            </p>
          </div>
        )}
      </Modal>

      {/* Security log modal */}
      <Modal open={logModal} onClose={() => setLogModal(false)} title="Журнал безпеки">
        <div className="flex flex-col gap-1.5 font-mono text-[11px]">
          {[
            ['14:02:11', 'LOGIN', 'Адмін AutoFarm · 192.168.1.50', 'var(--green)'],
            ['09:30:00', 'SESSION', 'Сесія оновлена', 'var(--cyan)'],
            ['08:15:42', 'PIN_OK', 'PIN підтверджено', 'var(--green)'],
            ['07:00:00', 'AUTO', 'Автологін за токеном', 'var(--cyan)'],
            ['23:14:08', 'LOGOUT', 'Сесія завершена (таймаут)', 'var(--muted-foreground)'],
          ].map((l, i) => (
            <div key={i} className="rounded-lg border bg-[var(--background)] px-2.5 py-2">
              <span className="text-muted-foreground">[{l[0]}] </span>
              <span style={{ color: l[3] }} className="font-bold">
                {l[1]}
              </span>
              <span className="text-foreground/80"> {l[2]}</span>
            </div>
          ))}
        </div>
      </Modal>

      {/* Lockdown modal */}
      <Modal open={lockModal} onClose={() => setLockModal(false)} title="LOCKDOWN">
        <p className="mb-3 text-sm">
          Заблокувати всю систему? Усі вузли перейдуть у безпечний режим, керування буде призупинено.
        </p>
        <Btn
          variant="red"
          className="w-full"
          onClick={() => {
            setLockModal(false)
          }}
        >
          🚨 ПІДТВЕРДИТИ LOCKDOWN
        </Btn>
        <p className="mt-2 text-center text-xs text-[var(--red)]">Система заблокована</p>
      </Modal>
    </Card>
  )
}

function PinInput({
  label,
  value,
  onChange,
}: {
  label: string
  value: string
  onChange: (v: string) => void
}) {
  return (
    <div className="mb-3">
      <label className="mb-1.5 block text-xs text-muted-foreground">{label}</label>
      <div className="flex items-center gap-2">
        <div className="flex flex-1 gap-1.5">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="flex h-9 flex-1 items-center justify-center rounded-lg border bg-[var(--background)] text-lg"
            >
              {value[i] ? '●' : ''}
            </div>
          ))}
        </div>
      </div>
      <input
        inputMode="numeric"
        value={value}
        maxLength={6}
        onChange={(e) => onChange(e.target.value.replace(/\D/g, ''))}
        className="mt-2 w-full rounded-lg border bg-[var(--background)] px-3 py-2 text-center font-mono text-sm tracking-[0.5em] outline-none focus:border-[var(--cyan)]"
        placeholder="••••••"
      />
    </div>
  )
}
