'use client'

import { useState } from 'react'
import { Card, Btn, TextInput, Modal, StatusDot } from '@/components/ui-kit'
import type { PageProps } from '../types'
import { Send } from 'lucide-react'

export function TelegramSection({ config, update }: PageProps) {
  const [saved, setSaved] = useState(false)
  const [testOpen, setTestOpen] = useState(false)

  const save = () => {
    if (config.telegramToken && config.telegramChatID) {
      update('telegramConnected', true)
      setSaved(true)
      setTimeout(() => setSaved(false), 2500)
    }
  }

  const reset = () => {
    update('telegramToken', '')
    update('telegramChatID', '')
    update('telegramBotName', '')
    update('telegramConnected', false)
  }

  return (
    <Card>
      <div className="mb-3 flex items-center gap-2">
        <Send size={16} color="var(--cyan)" />
        {config.telegramConnected ? (
          <span className="flex items-center gap-1.5 text-sm font-semibold text-[var(--green)]">
            <StatusDot color="var(--green)" /> ПІДКЛЮЧЕНО
          </span>
        ) : (
          <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <StatusDot color="var(--muted-foreground)" pulse={false} /> НЕ ПІДКЛЮЧЕНО
          </span>
        )}
      </div>

      <TextInput
        label="Bot Token"
        value={config.telegramToken}
        onChange={(v) => update('telegramToken', v)}
        placeholder="1234567890:ABCdef..."
        password
      />
      <TextInput
        label="Chat ID"
        value={config.telegramChatID}
        onChange={(v) => update('telegramChatID', v)}
        placeholder="-100123456789 або @username"
      />
      <TextInput
        label="Ім'я бота"
        value={config.telegramBotName}
        onChange={(v) => update('telegramBotName', v)}
        placeholder="@MyFarmBot"
      />

      <Btn variant="cyan" className="mb-2 w-full" onClick={save}>
        ЗБЕРЕГТИ БОТ НАЛАШТУВАННЯ
      </Btn>
      {saved && (
        <p className="mb-2 text-center text-xs font-semibold text-[var(--green)]">
          ✅ Налаштування збережено
        </p>
      )}

      <div className="mb-2 flex gap-2">
        <Btn
          variant="outline"
          className="flex-1 !text-xs"
          disabled={!config.telegramConnected}
          onClick={() => setTestOpen(true)}
        >
          ТЕСТ СПОВІЩЕННЯ
        </Btn>
        <Btn variant="redOutline" className="flex-1 !text-xs" onClick={reset}>
          СКИНУТИ
        </Btn>
      </div>

      <div className="rounded-lg border bg-[var(--background)] p-3 text-xs leading-relaxed text-muted-foreground">
        <p className="mb-1 font-semibold text-foreground">📋 Як створити бота:</p>
        <p>1. Відкрийте @BotFather в Telegram</p>
        <p>2. Надішліть /newbot</p>
        <p>3. Введіть назву та username</p>
        <p>4. Скопіюйте токен сюди</p>
        <p>5. Надішліть будь-яке повідомлення боту</p>
        <p>6. Отримайте Chat ID через @userinfobot</p>
      </div>

      <Modal open={testOpen} onClose={() => setTestOpen(false)} title="Тест сповіщення">
        <div className="rounded-xl border bg-[var(--background)] p-3">
          <div className="mb-2 flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--cyan)] text-xs font-bold text-[#001016]">
              AF
            </div>
            <span className="text-xs font-semibold">
              {config.telegramBotName || '@AutoFarmBot'}
            </span>
          </div>
          <div className="rounded-lg bg-card p-3 text-sm">
            <p className="mb-1 font-semibold">🦞 AutoFarm OS</p>
            <p className="text-muted-foreground">
              🌡️ Темп. води: {config.waterTemp.toFixed(1)}°C{'\n'}
            </p>
            <p className="text-muted-foreground">💨 Кисень: {config.oxygen.toFixed(1)} mg/L</p>
            <p className="text-[var(--green)]">✅ Всі системи в нормі</p>
          </div>
          <p className="mt-2 font-mono text-[10px] text-muted-foreground">
            Доставлено → Chat {config.telegramChatID}
          </p>
        </div>
      </Modal>
    </Card>
  )
}
