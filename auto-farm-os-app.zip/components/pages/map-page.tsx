'use client'

import { useMemo, useState } from 'react'
import { Card, SectionTitle, StatusDot, Modal, Btn } from '@/components/ui-kit'
import { MiniLineChart } from '@/components/mini-chart'
import type { Config } from '@/lib/config'
import { ChevronDown } from 'lucide-react'

interface Zone {
  id: string
  temp: number
  active: boolean
  status: 'ok' | 'off'
}

function genTempHistory(base: number) {
  return Array.from({ length: 24 }, (_, i) => ({
    h: `${i}:00`,
    temp: +(base + Math.sin(i / 3) * 0.6 + (Math.random() - 0.5) * 0.3).toFixed(1),
  }))
}

export function MapPage({ config }: { config: Config }) {
  const [open, setOpen] = useState<Record<number, boolean>>({ 1: true, 2: true, 3: true })
  const [zone, setZone] = useState<{ zone: Zone; pool: string } | null>(null)

  const pools = [
    {
      idx: 1,
      name: config.pool1Name,
      count: config.pool1Count,
      area: config.pool1Area,
      zones: [
        { id: 'П1-1', temp: 27.4, active: true, status: 'ok' as const },
        { id: 'П1-2', temp: 27.6, active: true, status: 'ok' as const },
        { id: 'П1-3', temp: 27.5, active: true, status: 'ok' as const },
      ],
    },
    {
      idx: 2,
      name: config.pool2Name,
      count: config.pool2Count,
      area: config.pool2Area,
      zones: [
        { id: 'П2-1', temp: 28.0, active: true, status: 'ok' as const },
        { id: 'П2-2', temp: 28.1, active: true, status: 'ok' as const },
        { id: 'П2-3', temp: 27.9, active: true, status: 'ok' as const },
      ],
    },
    {
      idx: 3,
      name: config.pool3Name,
      count: config.pool3Count,
      area: config.pool3Area,
      zones: [
        { id: 'П3-1', temp: 28.3, active: true, status: 'ok' as const },
        { id: 'П3-2', temp: 28.2, active: true, status: 'ok' as const },
        { id: 'П3-3', temp: 0, active: false, status: 'off' as const },
      ],
    },
  ]

  return (
    <div>
      <header className="mb-4 px-1">
        <h1 className="text-xl font-bold tracking-tight">Карта Ферми</h1>
        <p className="text-xs text-muted-foreground">Зони басейнів · розподіл вузлів</p>
      </header>

      <div className="mb-1 flex gap-2">
        <div className="flex-1 rounded-lg border bg-card p-2.5 text-center">
          <div className="font-mono text-base font-bold text-[var(--cyan)]">3</div>
          <div className="text-[9px] uppercase tracking-wide text-muted-foreground">Басейни</div>
        </div>
        <div className="flex flex-[2] items-center justify-center gap-2 rounded-lg border bg-card p-2.5">
          <StatusDot color="var(--green)" />
          <span className="text-sm font-semibold text-[var(--green)]">Всі норма</span>
        </div>
      </div>

      {pools.map((p) => (
        <div key={p.idx} className="mt-3">
          <Card>
            <button
              className="flex w-full items-center justify-between"
              onClick={() => setOpen((o) => ({ ...o, [p.idx]: !o[p.idx] }))}
            >
              <div className="flex items-center gap-2 text-left">
                <span className="text-lg">🦞</span>
                <div>
                  <p className="text-sm font-semibold">{p.name}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {p.count} особин · {p.area}м²
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="rounded px-1.5 py-0.5 text-[10px] font-semibold" style={{ backgroundColor: 'var(--green)22', color: 'var(--green)' }}>
                  НОРМА
                </span>
                <ChevronDown
                  size={18}
                  className="text-muted-foreground transition-transform"
                  style={{ transform: open[p.idx] ? 'rotate(180deg)' : 'none' }}
                />
              </div>
            </button>

            {open[p.idx] && (
              <div className="mt-3 grid grid-cols-3 gap-2 animate-fade-in">
                {p.zones.map((z) => {
                  const active = z.active
                  const color = active ? 'var(--green)' : 'var(--muted-foreground)'
                  return (
                    <button
                      key={z.id}
                      onClick={() => active && setZone({ zone: z, pool: p.name })}
                      className="rounded-lg border p-2.5 text-center transition-all active:scale-95"
                      style={{
                        borderColor: active ? 'var(--green)55' : 'var(--border)',
                        opacity: active ? 1 : 0.5,
                      }}
                    >
                      <div className="mb-1 text-base">🦞</div>
                      <div className="font-mono text-[11px] font-bold">{z.id}</div>
                      {active ? (
                        <div className="mt-1 flex items-center justify-center gap-1">
                          <StatusDot color={color} />
                          <span className="font-mono text-[10px]" style={{ color }}>
                            {z.temp}°
                          </span>
                        </div>
                      ) : (
                        <div className="mt-1 text-[9px] text-muted-foreground">ВІДКЛЮЧЕНО</div>
                      )}
                    </button>
                  )
                })}
              </div>
            )}
          </Card>
        </div>
      ))}

      <SectionTitle>МАТРИЦЯ ЗОН</SectionTitle>
      <div className="flex flex-col gap-2">
        {[
          { node: 'NODE A', zones: 'П1-1 · П1-2 · П1-3 · П2-1', color: 'var(--green)' },
          { node: 'NODE B', zones: 'П2-2 · П2-3 · П3-1 · П3-2', color: 'var(--green)' },
          { node: 'NODE C', zones: 'П3-3 (офлайн)', color: 'var(--red)' },
        ].map((m) => (
          <Card key={m.node} className="flex items-center justify-between !py-3">
            <div className="flex items-center gap-2">
              <StatusDot color={m.color} pulse={m.color !== 'var(--red)'} />
              <span className="font-mono text-sm font-bold">{m.node}</span>
            </div>
            <span className="font-mono text-[11px] text-muted-foreground">{m.zones}</span>
          </Card>
        ))}
      </div>

      <ZoneModal data={zone} config={config} onClose={() => setZone(null)} />
    </div>
  )
}

function ZoneModal({
  data,
  config,
  onClose,
}: {
  data: { zone: Zone; pool: string } | null
  config: Config
  onClose: () => void
}) {
  const history = useMemo(() => genTempHistory(data?.zone.temp ?? config.waterTemp), [data])
  if (!data) return null
  const { zone, pool } = data

  const readings = [
    { l: 'Temp', v: `${zone.temp}°C`, c: 'var(--green)' },
    { l: 'O₂', v: `${config.oxygen.toFixed(1)}`, c: 'var(--cyan)' },
    { l: 'pH', v: config.pH.toFixed(1), c: 'var(--green)' },
    { l: 'Ammonia', v: config.ammonia.toFixed(3), c: 'var(--green)' },
  ]

  return (
    <Modal open={!!data} onClose={onClose} title={`Зона ${zone.id}`}>
      <p className="mb-3 text-xs text-muted-foreground">{pool}</p>

      <p className="mb-1 text-[10px] uppercase tracking-wide text-muted-foreground">
        Температура за 24г
      </p>
      <div className="mb-4 rounded-lg border bg-[var(--background)] p-2">
        <MiniLineChart
          data={history}
          xKey="h"
          dataKeys={[{ key: 'temp', color: 'var(--cyan)', name: 'Temp °C' }]}
          height={160}
        />
      </div>

      <div className="mb-4 grid grid-cols-4 gap-2">
        {readings.map((r) => (
          <div key={r.l} className="rounded-lg border bg-[var(--background)] p-2 text-center">
            <div className="font-mono text-sm font-bold" style={{ color: r.c }}>
              {r.v}
            </div>
            <div className="text-[9px] text-muted-foreground">{r.l}</div>
          </div>
        ))}
      </div>

      <p className="mb-2 text-[10px] uppercase tracking-wide text-muted-foreground">
        Історія статусів
      </p>
      <div className="mb-4 flex flex-col gap-1.5">
        {[
          { t: '14:02', m: 'Температура в нормі', c: 'var(--green)' },
          { t: '11:30', m: 'Аерація активована', c: 'var(--cyan)' },
          { t: '08:15', m: 'Годування виконано', c: 'var(--cyan)' },
          { t: '06:00', m: 'Нічний цикл завершено', c: 'var(--muted-foreground)' },
        ].map((h, i) => (
          <div key={i} className="flex items-center gap-2 rounded-lg border bg-[var(--background)] px-2.5 py-2">
            <StatusDot color={h.c} pulse={false} />
            <span className="font-mono text-[11px] text-muted-foreground">{h.t}</span>
            <span className="text-xs">{h.m}</span>
          </div>
        ))}
      </div>

      <Btn variant="outline" className="w-full" onClick={onClose}>
        ЗАКРИТИ
      </Btn>
    </Modal>
  )
}
