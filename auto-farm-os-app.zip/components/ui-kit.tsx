'use client'

import type React from 'react'
import { useEffect, useState } from 'react'
import { X } from 'lucide-react'

export function Card({
  children,
  className = '',
  accent,
  onClick,
}: {
  children: React.ReactNode
  className?: string
  accent?: string
  onClick?: () => void
}) {
  return (
    <div
      onClick={onClick}
      className={`rounded-xl border bg-card p-4 ${className}`}
      style={accent ? { borderLeftWidth: 3, borderLeftColor: accent } : undefined}
    >
      {children}
    </div>
  )
}

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mb-2 mt-5 px-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
      {children}
    </h2>
  )
}

export function StatusDot({ color, pulse = true }: { color: string; pulse?: boolean }) {
  return (
    <span
      className={`inline-block h-2.5 w-2.5 rounded-full ${pulse ? 'animate-pulse-dot' : ''}`}
      style={{ backgroundColor: color, boxShadow: `0 0 6px ${color}` }}
    />
  )
}

export function Toggle({
  checked,
  onChange,
  disabled = false,
  color = 'var(--cyan)',
}: {
  checked: boolean
  onChange: (v: boolean) => void
  disabled?: boolean
  color?: string
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${
        disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'
      }`}
      style={{ backgroundColor: checked ? color : 'var(--border)' }}
    >
      <span
        className="absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all"
        style={{ left: checked ? 'calc(100% - 22px)' : '2px' }}
      />
    </button>
  )
}

export function Modal({
  open,
  onClose,
  title,
  children,
  fullScreen = false,
}: {
  open: boolean
  onClose: () => void
  title?: string
  children: React.ReactNode
  fullScreen?: boolean
}) {
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden'
      return () => {
        document.body.style.overflow = ''
      }
    }
  }, [open])

  if (!open) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm sm:items-center"
      onClick={onClose}
    >
      <div
        className={`animate-fade-in w-full max-w-[430px] overflow-hidden border bg-card ${
          fullScreen ? 'h-full rounded-none' : 'max-h-[90vh] rounded-t-2xl sm:rounded-2xl'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b px-4 py-3">
          <h3 className="text-sm font-semibold text-foreground">{title}</h3>
          <button onClick={onClose} aria-label="Закрити" className="text-muted-foreground">
            <X size={18} />
          </button>
        </div>
        <div className="no-scrollbar max-h-[calc(90vh-52px)] overflow-y-auto p-4">{children}</div>
      </div>
    </div>
  )
}

export function Btn({
  children,
  onClick,
  variant = 'cyan',
  className = '',
  disabled = false,
}: {
  children: React.ReactNode
  onClick?: () => void
  variant?: 'cyan' | 'purple' | 'red' | 'outline' | 'redOutline' | 'ghost'
  className?: string
  disabled?: boolean
}) {
  const styles: Record<string, React.CSSProperties> = {
    cyan: { backgroundColor: 'var(--cyan)', color: '#001016' },
    purple: { backgroundColor: 'var(--purple)', color: '#fff' },
    red: { backgroundColor: 'var(--red)', color: '#fff' },
    outline: { border: '1px solid var(--border)', color: 'var(--foreground)' },
    redOutline: { border: '1px solid var(--red)', color: 'var(--red)' },
    ghost: { color: 'var(--muted-foreground)' },
  }
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      style={styles[variant]}
      className={`rounded-lg px-4 py-2.5 text-sm font-semibold transition-all active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 ${className}`}
    >
      {children}
    </button>
  )
}

export function TextInput({
  label,
  value,
  onChange,
  placeholder,
  type = 'text',
  password = false,
  readOnly = false,
}: {
  label?: string
  value: string
  onChange?: (v: string) => void
  placeholder?: string
  type?: string
  password?: boolean
  readOnly?: boolean
}) {
  const [show, setShow] = useState(false)
  return (
    <div className="mb-3">
      {label && <label className="mb-1.5 block text-xs text-muted-foreground">{label}</label>}
      <div className="relative">
        <input
          type={password ? (show ? 'text' : 'password') : type}
          value={value}
          readOnly={readOnly}
          placeholder={placeholder}
          onChange={(e) => onChange?.(e.target.value)}
          className="w-full rounded-lg border bg-[var(--muted)] px-3 py-2.5 font-mono text-sm text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-[var(--cyan)] read-only:opacity-70"
        />
        {password && (
          <button
            type="button"
            onClick={() => setShow((s) => !s)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            aria-label="Показати"
          >
            <EyeToggle show={show} />
          </button>
        )}
      </div>
    </div>
  )
}

import { Eye, EyeOff } from 'lucide-react'
function EyeToggle({ show }: { show: boolean }) {
  return show ? <EyeOff size={16} /> : <Eye size={16} />
}

export function SegButtons<T extends string | number>({
  options,
  value,
  onChange,
  color = 'var(--cyan)',
}: {
  options: { label: string; value: T }[]
  value: T
  onChange: (v: T) => void
  color?: string
}) {
  return (
    <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
      {options.map((o) => {
        const active = o.value === value
        return (
          <button
            key={String(o.value)}
            type="button"
            onClick={() => onChange(o.value)}
            className="shrink-0 rounded-lg px-3 py-2 text-xs font-semibold transition-all"
            style={
              active
                ? { backgroundColor: color, color: color === 'var(--purple)' ? '#fff' : '#001016' }
                : { border: '1px solid var(--border)', color: 'var(--muted-foreground)' }
            }
          >
            {o.label}
          </button>
        )
      })}
    </div>
  )
}
