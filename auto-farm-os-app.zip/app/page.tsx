'use client'

import { useEffect, useState } from 'react'
import { Home, Cpu, Map, Brain, Settings } from 'lucide-react'
import { type Config, initialConfig } from '@/lib/config'
import { HomePage } from '@/components/pages/home-page'
import { EquipmentPage } from '@/components/pages/equipment-page'
import { MapPage } from '@/components/pages/map-page'
import { AIPage } from '@/components/pages/ai-page'
import { SettingsPage } from '@/components/pages/settings-page'

type Tab = 'home' | 'equip' | 'map' | 'ai' | 'settings'

const TABS: { id: Tab; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Головна', icon: Home },
  { id: 'equip', label: 'Обладнання', icon: Cpu },
  { id: 'map', label: 'Карта', icon: Map },
  { id: 'ai', label: 'ШІ', icon: Brain },
  { id: 'settings', label: 'Налаштування', icon: Settings },
]

const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v))

export default function Page() {
  const [tab, setTab] = useState<Tab>('home')
  const [config, setConfig] = useState<Config>(initialConfig)

  const update = <K extends keyof Config>(key: K, value: Config[K]) =>
    setConfig((c) => ({ ...c, [key]: value }))

  const updateMany = (patch: Partial<Config>) => setConfig((c) => ({ ...c, ...patch }))

  // theme switching
  useEffect(() => {
    const el = document.documentElement
    el.classList.remove('theme-amoled', 'theme-light')
    if (config.theme === 'amoled') el.classList.add('theme-amoled')
    if (config.theme === 'light') el.classList.add('theme-light')
  }, [config.theme])

  // live sensor fluctuation every 5s
  useEffect(() => {
    const id = setInterval(() => {
      setConfig((c) => ({
        ...c,
        waterTemp: clamp(c.waterTemp + (Math.random() - 0.5) * 0.2, 24, 30),
        oxygen: clamp(c.oxygen + (Math.random() - 0.5) * 0.2, 4, 9),
        pH: clamp(c.pH + (Math.random() - 0.5) * 0.04, 7, 9),
        ammonia: clamp(c.ammonia + (Math.random() - 0.5) * 0.002, 0, 0.06),
        humidity: clamp(c.humidity + (Math.random() - 0.5) * 1.2, 60, 92),
        airTemp: clamp(c.airTemp + (Math.random() - 0.5) * 0.2, 20, 32),
      }))
    }, 5000)
    return () => clearInterval(id)
  }, [])

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-[430px] flex-col bg-background">
      <div key={tab} className="animate-fade-in flex-1 px-3 pb-24 pt-4">
        {tab === 'home' && <HomePage config={config} update={update} />}
        {tab === 'equip' && <EquipmentPage config={config} update={update} />}
        {tab === 'map' && <MapPage config={config} />}
        {tab === 'ai' && <AIPage config={config} update={update} />}
        {tab === 'settings' && (
          <SettingsPage config={config} update={update} updateMany={updateMany} />
        )}
      </div>

      <nav className="fixed bottom-0 left-1/2 z-40 w-full max-w-[430px] -translate-x-1/2 border-t bg-card/95 backdrop-blur">
        <div className="flex items-stretch justify-around px-1 pb-[env(safe-area-inset-bottom)]">
          {TABS.map((t) => {
            const Icon = t.icon
            const active = tab === t.id
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className="flex flex-1 flex-col items-center gap-0.5 py-2.5 transition-colors"
                style={{ color: active ? 'var(--cyan)' : 'var(--muted-foreground)' }}
              >
                <Icon size={20} strokeWidth={active ? 2.4 : 1.8} />
                <span className="text-[9px] font-medium">{t.label}</span>
              </button>
            )
          })}
        </div>
      </nav>
    </main>
  )
}
