export interface Config {
  // Network
  serverIP: string
  serverPort: string
  mqttIP: string
  mqttPort: string
  wifiName: string

  // Telegram
  telegramToken: string
  telegramChatID: string
  telegramBotName: string
  telegramConnected: boolean

  // Nodes IP
  nodeA_IP: string
  nodeB_IP: string
  nodeC_IP: string

  // Thresholds
  tempMin: number
  tempMax: number
  tempOptimalMin: number
  tempOptimalMax: number
  o2Min: number
  o2Optimal: number
  phMin: number
  phMax: number
  ammoniaMax: number
  humidityMax: number

  // Farm config
  pool1Name: string
  pool2Name: string
  pool3Name: string
  pool1Count: number
  pool2Count: number
  pool3Count: number
  pool1Area: number
  pool2Area: number
  pool3Area: number

  // Sensors (mock live data)
  waterTemp: number
  oxygen: number
  pH: number
  ammonia: number
  humidity: number
  airTemp: number

  // Ventilation
  intakeFanSpeed: number
  exhaustFanSpeed: number
  fanSyncMode: boolean

  // AI protocols
  aiMode: string
  proto_o2: boolean
  proto_thermal: boolean
  proto_feeding: boolean
  proto_molting: boolean
  proto_humidity: boolean
  proto_growth: boolean

  // Security
  pinEnabled: boolean
  twoFactorEnabled: boolean
  sessionTimeout: number

  // System
  logRetention: string
  pollInterval: string
  soundAlerts: boolean
  language: string
  theme: string

  // Calibration
  tempOffset: number
  o2Offset: number
  phOffset: number

  // Notifications
  notifyWarnings: boolean
  notifyDailyReport: boolean
  notifyMolting: boolean
  notifyFeeding: boolean
  notifyAI: boolean
  notifyQuiet: boolean

  // Extra system
  autoReconnect: boolean
  mqttBroker: boolean
  vibration: boolean
  logLanguage: string

  // Farm meta
  farmName: string
  totalArea: number
  launchDate: string
  adminName: string
  adminRole: string
}

export const initialConfig: Config = {
  serverIP: '',
  serverPort: '3000',
  mqttIP: '192.168.1.200',
  mqttPort: '1883',
  wifiName: '',

  telegramToken: '',
  telegramChatID: '',
  telegramBotName: '',
  telegramConnected: false,

  nodeA_IP: '192.168.1.101',
  nodeB_IP: '192.168.1.102',
  nodeC_IP: '192.168.1.103',

  tempMin: 24.0,
  tempMax: 29.5,
  tempOptimalMin: 27.0,
  tempOptimalMax: 28.5,
  o2Min: 5.0,
  o2Optimal: 7.0,
  phMin: 7.5,
  phMax: 8.5,
  ammoniaMax: 0.05,
  humidityMax: 85,

  pool1Name: 'Басейн 1 — Молодь',
  pool2Name: 'Басейн 2 — Вирощування',
  pool3Name: 'Басейн 3 — Товарні',
  pool1Count: 150,
  pool2Count: 85,
  pool3Count: 40,
  pool1Area: 6,
  pool2Area: 8,
  pool3Area: 10,

  waterTemp: 27.5,
  oxygen: 7.1,
  pH: 7.8,
  ammonia: 0.008,
  humidity: 74,
  airTemp: 26.3,

  intakeFanSpeed: 45,
  exhaustFanSpeed: 45,
  fanSyncMode: true,

  aiMode: 'АВТОНОМНИЙ',
  proto_o2: true,
  proto_thermal: true,
  proto_feeding: true,
  proto_molting: false,
  proto_humidity: false,
  proto_growth: false,

  pinEnabled: true,
  twoFactorEnabled: false,
  sessionTimeout: 5,

  logRetention: '14d',
  pollInterval: '5s',
  soundAlerts: true,
  language: 'ua',
  theme: 'cyber_dark',

  tempOffset: 0.0,
  o2Offset: 0.0,
  phOffset: 0.0,

  notifyWarnings: true,
  notifyDailyReport: true,
  notifyMolting: true,
  notifyFeeding: false,
  notifyAI: true,
  notifyQuiet: false,

  autoReconnect: true,
  mqttBroker: true,
  vibration: true,
  logLanguage: 'tech',

  farmName: 'AutoFarm Кременчук',
  totalArea: 24,
  launchDate: '2024-03-15',
  adminName: 'Адмін AutoFarm',
  adminRole: 'Головний оператор',
}

export type SensorStatus = 'ok' | 'warn' | 'critical'

export const statusColor: Record<SensorStatus, string> = {
  ok: 'var(--green)',
  warn: 'var(--orange)',
  critical: 'var(--red)',
}

export function tempStatus(v: number, c: Config): SensorStatus {
  if (v < c.tempMin || v > c.tempMax) return 'critical'
  if (v < c.tempOptimalMin || v > c.tempOptimalMax) return 'warn'
  return 'ok'
}
export function o2Status(v: number, c: Config): SensorStatus {
  if (v < c.o2Min) return 'critical'
  if (v < c.o2Optimal) return 'warn'
  return 'ok'
}
export function phStatus(v: number, c: Config): SensorStatus {
  if (v < c.phMin || v > c.phMax) return 'critical'
  if (v < c.phMin + 0.2 || v > c.phMax - 0.2) return 'warn'
  return 'ok'
}
export function ammoniaStatus(v: number, c: Config): SensorStatus {
  if (v > c.ammoniaMax) return 'critical'
  if (v > c.ammoniaMax * 0.6) return 'warn'
  return 'ok'
}
export function humidityStatus(v: number, c: Config): SensorStatus {
  if (v > c.humidityMax) return 'critical'
  if (v > 75) return 'warn'
  return 'ok'
}
