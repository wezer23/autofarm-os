// AutoFarm OS — JARVIS Service Worker v2.4.1
const CACHE_NAME = 'autofarm-jarvis-v2.4.1'
const OFFLINE_URL = '/offline.html'

// Файли для кешування при встановленні
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/offline.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
]

// Встановлення — кешуємо основні файли
self.addEventListener('install', (event) => {
  console.log('[JARVIS SW] Installing...')
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[JARVIS SW] Pre-caching assets')
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.log('[JARVIS SW] Pre-cache error (non-fatal):', err)
      })
    })
  )
  self.skipWaiting()
})

// Активація — видаляємо старі кеші
self.addEventListener('activate', (event) => {
  console.log('[JARVIS SW] Activating...')
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => {
            console.log('[JARVIS SW] Deleting old cache:', name)
            return caches.delete(name)
          })
      )
    })
  )
  self.clients.claim()
})

// Fetch — стратегія Network First з fallback на кеш
self.addEventListener('fetch', (event) => {
  // Пропускаємо не-GET запити та API запити
  if (event.request.method !== 'GET') return
  if (event.request.url.includes('/api/')) return

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Зберігаємо успішну відповідь в кеш
        if (response && response.status === 200) {
          const responseClone = response.clone()
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone)
          })
        }
        return response
      })
      .catch(() => {
        // Немає мережі — повертаємо з кешу
        return caches.match(event.request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse
          }
          // Якщо немає в кеші — офлайн сторінка
          if (event.request.destination === 'document') {
            return caches.match(OFFLINE_URL)
          }
        })
      })
  )
})

// Push сповіщення від Telegram бота
self.addEventListener('push', (event) => {
  if (!event.data) return

  let data
  try {
    data = event.data.json()
  } catch {
    data = { title: 'AutoFarm OS', body: event.data.text() }
  }

  const options = {
    body: data.body || 'Нове сповіщення від JARVIS',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-72.png',
    vibrate: data.critical ? [200, 100, 200, 100, 200] : [100, 50, 100],
    data: {
      url: data.url || '/',
      critical: data.critical || false,
    },
    actions: data.critical
      ? [
          { action: 'view', title: '🔍 Деталі' },
          { action: 'resolve', title: '✅ Вирішено' },
        ]
      : [{ action: 'view', title: '👁️ Переглянути' }],
    tag: data.tag || 'autofarm-notification',
    requireInteraction: data.critical || false,
    silent: false,
  }

  event.waitUntil(
    self.registration.showNotification(
      data.title || '🦞 AutoFarm OS',
      options
    )
  )
})

// Обробка кліку на сповіщення
self.addEventListener('notificationclick', (event) => {
  event.notification.close()

  const url = event.notification.data?.url || '/'

  event.waitUntil(
    clients
      .matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        // Якщо додаток відкритий — фокусуємо
        for (const client of clientList) {
          if (client.url.includes(self.location.origin) && 'focus' in client) {
            return client.focus()
          }
        }
        // Якщо не відкритий — відкриваємо
        if (clients.openWindow) {
          return clients.openWindow(url)
        }
      })
  )
})

// Фонова синхронізація даних
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-sensor-data') {
    event.waitUntil(syncSensorData())
  }
})

async function syncSensorData() {
  console.log('[JARVIS SW] Background sync: sensor data')
  // Тут буде синхронізація з ESP32 коли з\'явиться мережа
}

console.log('[JARVIS SW] Service Worker loaded — AutoFarm OS v2.4.1')
