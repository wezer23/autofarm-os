import React, { useState, useEffect } from 'react'
import BottomNav from './components/BottomNav'
import PWAInstall from './components/PWAInstall'
import ArcReactor from './components/ArcReactor'
import Home from './pages/Home'
import Equipment from './pages/Equipment'
import Map from './pages/Map'
import AIPage from './pages/AI'
import Settings from './pages/Settings'

const BOOT_LINES = [
  '> AUTOFARM OS v2.4.1',
  '> INITIALIZING JARVIS CORE...',
  '> ████████████████████ 100%',
  '>',
  '> ЗАВАНТАЖЕННЯ НЕЙРОННОГО ДВИГУНА...',
  '> MODEL: AutoFarm-NLP-v4 ........... OK',
  '> ПІДКЛЮЧЕННЯ ДАТЧИКІВ ............. OK',
  '> ПРОТОКОЛ БЕЗПЕКИ ................. OK',
  '> МОНІТОРИНГ БАСЕЙНІВ .............. OK',
  '> TELEGRAM ІНТЕГРАЦІЯ .............. OK',
  '>',
  '> ШІ ЯДРО АКТИВОВАНО',
  '> Всі системи в нормі.',
  '> Раки під захистом.',
  '>',
  '> ЛАСКАВО ПРОСИМО, АДМІНЕ.',
]

const INITIAL_CONFIG = {
  serverIP: '',
  serverPort: '3000',
  mqttIP: '192.168.1.200',
  mqttPort: '1883',
  wifiName: '',
  apiToken: '',
  telegramToken: '',
  telegramChatID: '',
  telegramBotName: '',
  telegramConnected: false,
  nodeA_IP: '192.168.1.101',
  nodeB_IP: '192.168.1.102',
  nodeC_IP: '192.168.1.103',
  tempMin: 24.0,
  tempMax: 29.5,
  tempOptimalMin: 27.0,
  tempOptimalMax: 28.5,
  o2Min: 5.0,
  o2Optimal: 7.0,
  phMin: 7.5,
  phMax: 8.5,
  ammoniaMax: 0.05,
  humidityMax: 85,
  pool1Name: 'Басейн 1 — Молодь',
  pool2Name: 'Басейн 2 — Вирощування',
  pool3Name: 'Басейн 3 — Товарні',
  pool1Count: 150,
  pool2Count: 85,
  pool3Count: 40,
  pool1Area: 6,
  pool2Area: 8,
  pool3Area: 10,
  waterTemp: 27.5,
  oxygen: 7.1,
  pH: 7.8,
  ammonia: 0.008,
  humidity: 74,
  airTemp: 26.3,
  intakeFanSpeed: 45,
  exhaustFanSpeed: 45,
  fanSyncMode: true,
  aiMode: 'АВТОНОМНИЙ',
  proto_o2: true,
  proto_thermal: true,
  proto_feeding: true,
  proto_molting: false,
  proto_humidity: false,
  proto_growth: false,
  pinEnabled: true,
  twoFactorEnabled: false,
  sessionTimeout: 5,
  logRetention: '14d',
  pollInterval: '5s',
  soundAlerts: true,
  autoReconnect: true,
  mqttEnabled: true,
  quietMode: true,
  notifWarnings: true,
  notifDaily: true,
  notifMolting: true,
  notifFeeding: false,
  notifAI: false,
  language: 'ua',
  theme: 'cyber_dark',
  tempOffset: 0.0,
  o2Offset: 0.0,
  phOffset: 0.0,
}

export default function App() {
  const [booting, setBooting] = useState(true)
  const [bootLines, setBootLines] = useState([])
  const [bootDone, setBootDone] = useState(false)
  const [activeTab, setActiveTab] = useState('home')
  const [config, setConfig] = useState(INITIAL_CONFIG)

  // Boot sequence
  useEffect(() => {
    let i = 0
    const timer = setInterval(() => {
      if (i < BOOT_LINES.length) {
        setBootLines(prev => [...prev, BOOT_LINES[i]])
        i++
      } else {
        clearInterval(timer)
        setBootDone(true)
        setTimeout(() => setBooting(false), 1000)
      }
    }, 120)
    return () => clearInterval(timer)
  }, [])

  // Live sensor simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setConfig(prev => ({
        ...prev,
        waterTemp: Math.max(26, Math.min(29, prev.waterTemp + (Math.random() - 0.5) * 0.15)),
        oxygen: Math.max(6.5, Math.min(8.0, prev.oxygen + (Math.random() - 0.5) * 0.08)),
        pH: Math.max(7.4, Math.min(8.2, prev.pH + (Math.random() - 0.5) * 0.04)),
        ammonia: Math.max(0.005, Math.min(0.02, prev.ammonia + (Math.random() - 0.5) * 0.001)),
        humidity: Math.max(65, Math.min(82, prev.humidity + (Math.random() - 0.5) * 0.8)),
        airTemp: Math.max(24, Math.min(28, prev.airTemp + (Math.random() - 0.5) * 0.1)),
      }))
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  // Boot screen
  if (booting) {
    return (
      <div className="boot-screen hex-bg">
        <div style={{ marginBottom: 30 }}>
          <ArcReactor size={90} status="normal" />
        </div>
        <div style={{
          width: '85%', maxWidth: 340,
          background: 'rgba(0,10,30,0.8)',
          border: '1px solid rgba(0,150,255,0.3)',
          borderRadius: 6, padding: 20,
          fontFamily: 'Courier New, monospace',
          fontSize: 11,
          minHeight: 280,
        }}>
          {bootLines.map((line, i) => (
            <div key={i} style={{
              color: line.includes('OK') ? '#00ff88' :
                     line.includes('JARVIS') || line.includes('ЯДРО') ? '#8B5CF6' :
                     line.includes('ЛАСКАВО') || line.includes('Раки') ? '#00c8ff' :
                     line.startsWith('>') ? '#a0d4ff' : '#3a5a7a',
              marginBottom: 3,
              animation: i === bootLines.length - 1 ? 'none' : 'none',
            }}>
              {line}
            </div>
          ))}
          {!bootDone && (
            <span style={{ color: '#00c8ff', animation: 'blink 0.8s infinite' }}>█</span>
          )}
          {bootDone && (
            <div style={{ marginTop: 16, textAlign: 'center', color: '#00c8ff', fontSize: 12, letterSpacing: '0.2em' }}>
              ЗАПУСК...
            </div>
          )}
        </div>
        <div style={{ marginTop: 20, fontSize: 9, color: '#1a3a5a', letterSpacing: '0.3em' }}>
          AUTOFARM OS — CHERAX QUADRICARINATUS
        </div>
      </div>
    )
  }

  const pages = {
    home: <Home config={config} setConfig={setConfig} />,
    equipment: <Equipment config={config} setConfig={setConfig} />,
    map: <Map config={config} setConfig={setConfig} />,
    ai: <AIPage config={config} setConfig={setConfig} />,
    settings: <Settings config={config} setConfig={setConfig} />,
  }

  return (
    <div style={{ background: '#000510', minHeight: '100vh', position: 'relative' }}>
      {/* Top bar */}
      <div style={{
        position: 'fixed', top: 0, left: '50%', transform: 'translateX(-50%)',
        width: '100%', maxWidth: 430,
        background: 'rgba(0,5,16,0.95)',
        borderBottom: '1px solid rgba(0,150,255,0.2)',
        padding: '8px 16px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        zIndex: 90,
        backdropFilter: 'blur(10px)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <ArcReactor size={24} status="normal" />
          <div>
            <div style={{ fontSize: 10, color: '#00c8ff', letterSpacing: '0.2em', fontWeight: 'bold' }}>
              AUTOFARM OS
            </div>
            <div style={{ fontSize: 7, color: '#3a5a7a', letterSpacing: '0.1em' }}>
              JARVIS ACTIVE ●
            </div>
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 9, color: '#00ff88' }}>● ALL SYSTEMS GO</div>
          <div style={{ fontSize: 7, color: '#3a5a7a' }}>
            {new Date().toLocaleTimeString('uk-UA', { hour12: false })}
          </div>
        </div>
      </div>

      {/* Main content with top padding */}
      <div style={{ paddingTop: 52 }}>
        {pages[activeTab]}
      </div>

      <BottomNav active={activeTab} onChange={setActiveTab} />
    </div>
  )
}

// PWAInstall is imported and shown in header
