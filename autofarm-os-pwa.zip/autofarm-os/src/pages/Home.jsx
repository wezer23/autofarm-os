import React, { useState, useEffect, useRef } from 'react'
import HudPanel from '../components/HudPanel'
import SensorCard from '../components/SensorCard'
import Modal from '../components/Modal'

const logs = [
  'SYS::OK   waterTemp nominal 27.5°C',
  'AI::ACK   feeding confirmed Pool-2',
  'SYS::OK   O2 level optimal 7.1 mg/L',
  'AI::WARN  humidity approaching 75%',
  'SYS::ACK  ventilation adjusted +5%',
  'AI::OK    pH stable 7.8 НОРМА',
  'SYS::OK   aeration Pool-1 active',
  'AI::INFO  molt prediction updated',
]

export default function Home({ config, setConfig }) {
  const [logLines, setLogLines] = useState(logs)
  const [voiceModal, setVoiceModal] = useState(false)
  const [voiceText, setVoiceText] = useState('JARVIS СЛУХАЄ...')
  const [isListening, setIsListening] = useState(false)
  const logRef = useRef(null)

  const getStatus = (val, min, max) => {
    if (val < min || val > max) return 'critical'
    const warn = (max - min) * 0.15
    if (val < min + warn || val > max - warn) return 'warning'
    return 'normal'
  }

  useEffect(() => {
    const timer = setInterval(() => {
      const time = new Date().toLocaleTimeString('uk-UA', { hour12: false })
      const msgs = [
        `SYS::OK   heartbeat nominal ${time}`,
        `AI::SCAN  Pool-1 temp ${config.waterTemp.toFixed(1)}°C`,
        `SYS::OK   O2 check: ${config.oxygen.toFixed(1)} mg/L`,
        `AI::INFO  ventilation ${config.intakeFanSpeed}% active`,
      ]
      const newLine = msgs[Math.floor(Math.random() * msgs.length)]
      setLogLines(prev => [...prev.slice(-20), newLine])
    }, 4000)
    return () => clearInterval(timer)
  }, [config])

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
  }, [logLines])

  const handleVoice = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      alert('Голосове керування не підтримується цим браузером')
      return
    }
    setVoiceModal(true)
    setIsListening(true)
    setVoiceText('JARVIS СЛУХАЄ...')

    const SR = window.SpeechRecognition || window.webkitSpeechRecognition
    const recognition = new SR()
    recognition.lang = 'uk-UA'
    recognition.onresult = (e) => {
      const text = e.results[0][0].transcript
      setVoiceText(`Команда: "${text}"`)
      setIsListening(false)
      setTimeout(() => {
        setVoiceText(processVoiceCommand(text))
      }, 500)
    }
    recognition.onerror = () => {
      setVoiceText('Помилка розпізнавання. Спробуйте ще.')
      setIsListening(false)
    }
    recognition.start()
  }

  const processVoiceCommand = (text) => {
    const t = text.toLowerCase()
    if (t.includes('стоп') || t.includes('аварія') || t.includes('зупини')) {
      speak('Сер, аварійна зупинка активована!')
      return '🚨 АВАРІЙНА ЗУПИНКА АКТИВОВАНА'
    }
    if (t.includes('статус') || t.includes('стан')) {
      speak(`Сер, всі системи в нормі. Температура ${config.waterTemp.toFixed(1)} градусів. Кисень ${config.oxygen.toFixed(1)} міліграм.`)
      return `✅ Температура: ${config.waterTemp.toFixed(1)}°C | O₂: ${config.oxygen.toFixed(1)} mg/L | pH: ${config.pH}`
    }
    if (t.includes('температур')) {
      speak(`Температура води ${config.waterTemp.toFixed(1)} градусів. Норма.`)
      return `🌡️ Температура: ${config.waterTemp.toFixed(1)}°C — НОРМА`
    }
    if (t.includes('кисень') || t.includes('кисн')) {
      speak(`Кисень ${config.oxygen.toFixed(1)} міліграм. Норма.`)
      return `💧 Кисень: ${config.oxygen.toFixed(1)} mg/L — НОРМА`
    }
    if (t.includes('вологість')) {
      speak(`Вологість ${config.humidity} відсотків.`)
      return `💨 Вологість: ${config.humidity}%`
    }
    speak('Сер, команда не розпізнана. Спробуйте ще раз.')
    return '❓ Команда не розпізнана'
  }

  const speak = (text) => {
    if ('speechSynthesis' in window) {
      const utter = new SpeechSynthesisUtterance(text)
      utter.lang = 'uk-UA'
      utter.rate = 0.9
      window.speechSynthesis.speak(utter)
    }
  }

  const humidityStatus = config.humidity > 85 ? 'critical' : config.humidity > 75 ? 'warning' : 'normal'

  return (
    <div className="content-area hex-bg" style={{ padding: '10px' }}>
      {/* Header */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        marginBottom: 12, padding: '8px 4px',
      }}>
        <div>
          <div style={{ fontSize: 11, color: '#00c8ff', letterSpacing: '0.3em', textTransform: 'uppercase' }}>
            AutoFarm OS
          </div>
          <div style={{ fontSize: 9, color: '#3a5a7a', letterSpacing: '0.15em' }}>
            JARVIS CORE ACTIVE ●
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 9, color: '#00ff88' }}>ALL SYSTEMS GO</div>
          <div style={{ fontSize: 9, color: '#3a5a7a' }}>UPTIME: 14D 6H</div>
        </div>
      </div>

      {/* Top stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6, marginBottom: 10 }}>
        {[
          { label: 'Басейни', value: '3', color: '#00ff88' },
          { label: 'Темп °C', value: config.waterTemp.toFixed(1), color: '#00c8ff' },
          { label: 'O₂ mg/L', value: config.oxygen.toFixed(1), color: '#00c8ff' },
          { label: 'Тривоги', value: '0', color: '#00ff88' },
        ].map((s, i) => (
          <div key={i} style={{
            background: 'rgba(0,15,40,0.8)',
            border: '1px solid rgba(0,150,255,0.2)',
            borderRadius: 4, padding: '8px 4px', textAlign: 'center',
          }}>
            <div style={{ fontSize: 18, fontWeight: 'bold', color: s.color, textShadow: `0 0 8px ${s.color}` }}>
              {s.value}
            </div>
            <div style={{ fontSize: 8, color: '#3a5a7a', letterSpacing: '0.1em' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* AI Predictions */}
      <HudPanel title="ПРОГНОЗИ JARVIS">
        {[
          { icon: '🦞', text: `Линяння: ${config.pool2Name} → ~3 дні` },
          { icon: '📦', text: `Збір: ${config.pool3Name} → ~11 днів (~18кг)` },
          { icon: '🌡️', text: `Темп стабільна ${config.tempOptimalMin}-${config.tempOptimalMax}°C` },
        ].map((p, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0',
            borderBottom: i < 2 ? '1px solid rgba(0,150,255,0.1)' : 'none',
          }}>
            <span style={{ fontSize: 14 }}>{p.icon}</span>
            <span style={{ fontSize: 11, color: '#a0d4ff' }}>{p.text}</span>
          </div>
        ))}
      </HudPanel>

      {/* Ventilation */}
      <HudPanel title="ВЕНТИЛЯЦІЯ КОНТРОЛЬ">
        <div style={{ marginBottom: 8 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
            <span style={{ fontSize: 10, color: '#3a5a7a', letterSpacing: '0.1em' }}>ВОЛОГІСТЬ</span>
            <span style={{
              fontSize: 12, fontWeight: 'bold',
              color: humidityStatus === 'critical' ? '#ff2020' : humidityStatus === 'warning' ? '#ff8c00' : '#00ff88',
            }}>{config.humidity}%</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <span style={{ fontSize: 10, color: '#3a5a7a' }}>ТЕМП. ПОВІТРЯ</span>
            <span style={{ fontSize: 12, color: '#00c8ff' }}>{config.airTemp.toFixed(1)}°C</span>
          </div>
        </div>

        {[
          { label: 'ПРИПЛИВ (Air Intake)', key: 'intakeFanSpeed' },
          { label: 'ВИТЯЖКА (Air Exhaust)', key: 'exhaustFanSpeed' },
        ].map(fan => (
          <div key={fan.key} style={{ marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ fontSize: 9, color: '#3a5a7a', letterSpacing: '0.1em' }}>{fan.label}</span>
              <span style={{ fontSize: 12, color: '#00c8ff', fontWeight: 'bold' }}>{config[fan.key]}%</span>
            </div>
            <input
              type="range" min="0" max="100"
              value={config[fan.key]}
              onChange={e => {
                const val = Number(e.target.value)
                if (config.fanSyncMode) {
                  setConfig(p => ({ ...p, intakeFanSpeed: val, exhaustFanSpeed: val }))
                } else {
                  setConfig(p => ({ ...p, [fan.key]: val }))
                }
              }}
            />
          </div>
        ))}

        <div className="toggle-container">
          <span style={{ fontSize: 10, color: '#a0d4ff', letterSpacing: '0.1em' }}>◈ СИНХРОННИЙ РЕЖИМ</span>
          <div
            className={`toggle ${config.fanSyncMode ? 'on' : 'off'}`}
            onClick={() => setConfig(p => ({ ...p, fanSyncMode: !p.fanSyncMode }))}
          />
        </div>

        <div style={{
          marginTop: 8, padding: '6px 10px', borderRadius: 4,
          background: humidityStatus === 'critical' ? 'rgba(255,32,32,0.1)' : 'rgba(0,255,136,0.05)',
          border: `1px solid ${humidityStatus === 'critical' ? '#ff202033' : '#00ff8833'}`,
        }}>
          <span style={{
            fontSize: 10,
            color: humidityStatus === 'critical' ? '#ff2020' : humidityStatus === 'warning' ? '#ff8c00' : '#00ff88',
          }}>
            {humidityStatus === 'critical' ? '🚨 КРИТИЧНА вологість — 100%!' :
             humidityStatus === 'warning' ? '⚠️ Підвищена вологість' :
             '✓ Вентиляція в нормі'}
          </span>
        </div>
      </HudPanel>

      {/* Sensors */}
      <HudPanel title="СТАН ДАТЧИКІВ — LIVE">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          <SensorCard label="ТЕМП. ВОДИ" value={config.waterTemp.toFixed(1)} unit="°C"
            status={getStatus(config.waterTemp, config.tempMin, config.tempMax)} />
          <SensorCard label="КИСЕНЬ" value={config.oxygen.toFixed(1)} unit="mg/L"
            status={getStatus(config.oxygen, config.o2Min, 12)} />
          <SensorCard label="pH" value={config.pH.toFixed(1)} unit="НОРМА"
            status={getStatus(config.pH, config.phMin, config.phMax)} />
          <SensorCard label="АМІАК" value={config.ammonia.toFixed(3)} unit="mg/L"
            status={config.ammonia > config.ammoniaMax ? 'critical' : config.ammonia > config.ammoniaMax * 0.7 ? 'warning' : 'normal'} />
          <SensorCard label="ВОЛОГІСТЬ" value={config.humidity} unit="%"
            status={humidityStatus} />
          <SensorCard label="ТЕМП. ПОВІТРЯ" value={config.airTemp.toFixed(1)} unit="°C" status="normal" />
        </div>
      </HudPanel>

      {/* JARVIS Terminal */}
      <HudPanel title="JARVIS ТЕРМІНАЛ">
        <div className="terminal" ref={logRef}>
          {logLines.map((line, i) => (
            <div key={i} style={{
              color: line.includes('WARN') ? '#ff8c00' : line.includes('OK') ? '#00ff88' : '#00c8ff',
              marginBottom: 2,
            }}>
              <span style={{ color: '#3a5a7a' }}>
                [{new Date().toLocaleTimeString('uk-UA', { hour12: false })}]
              </span>{' '}
              {line}
            </div>
          ))}
          <span style={{ color: '#00c8ff', animation: 'blink 1s infinite' }}>█</span>
        </div>
      </HudPanel>

      {/* Voice button */}
      <button
        onClick={handleVoice}
        style={{
          position: 'fixed',
          bottom: 80, right: 16,
          width: 52, height: 52,
          borderRadius: '50%',
          background: 'rgba(0,200,255,0.15)',
          border: '2px solid #00c8ff',
          boxShadow: '0 0 20px rgba(0,200,255,0.4)',
          fontSize: 22,
          cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 50,
        }}
      >🎤</button>

      {/* Voice modal */}
      {voiceModal && (
        <Modal title="JARVIS ГОЛОСОВА КОМАНДА" onClose={() => { setVoiceModal(false); setIsListening(false) }}>
          <div style={{ textAlign: 'center', padding: '20px 0' }}>
            <div style={{
              width: 80, height: 80, borderRadius: '50%', margin: '0 auto 16px',
              background: isListening ? 'rgba(0,200,255,0.2)' : 'rgba(0,150,255,0.1)',
              border: `2px solid ${isListening ? '#00c8ff' : '#3a5a7a'}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 32,
              boxShadow: isListening ? '0 0 30px rgba(0,200,255,0.5)' : 'none',
              animation: isListening ? 'coreGlow 1s infinite' : 'none',
            }}>
              {isListening ? '🎤' : '✅'}
            </div>
            <div style={{ color: '#00c8ff', fontSize: 13, letterSpacing: '0.1em' }}>{voiceText}</div>
            <div style={{ marginTop: 12, fontSize: 10, color: '#3a5a7a' }}>
              Команди: "статус", "температура", "кисень", "стоп"
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}
