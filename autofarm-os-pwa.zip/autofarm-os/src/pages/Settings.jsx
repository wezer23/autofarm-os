import React, { useState } from 'react'
import HudPanel from '../components/HudPanel'
import Modal from '../components/Modal'

export default function Settings({ config, setConfig }) {
  const [pinModal, setPinModal] = useState(false)
  const [pin, setPin] = useState('')
  const [pinConfirm, setPinConfirm] = useState('')
  const [pinStep, setPinStep] = useState(1)
  const [secLogModal, setSecLogModal] = useState(false)
  const [telegramSaved, setTelegramSaved] = useState(false)
  const [showToken, setShowToken] = useState(false)

  const securityLogs = [
    { time: '2024-06-15 03:47', type: 'LOGIN_FAIL', detail: 'IP: 192.168.1.145 — заблоковано 30хв' },
    { time: '2024-06-15 09:15', type: 'LOGIN_OK', detail: 'Адмін AutoFarm — успішний вхід' },
    { time: '2024-06-15 14:32', type: 'CONFIG', detail: 'Змінено порогові значення' },
    { time: '2024-06-14 22:01', type: 'LOGIN_OK', detail: 'Адмін AutoFarm — вхід' },
    { time: '2024-06-14 08:30', type: 'SYSTEM', detail: 'AutoFarm OS запущено v2.4.1' },
  ]

  const saveTelegram = () => {
    if (!config.telegramToken || !config.telegramChatID) {
      alert('Заповніть Token та Chat ID')
      return
    }
    setConfig(p => ({ ...p, telegramConnected: true }))
    setTelegramSaved(true)
    setTimeout(() => setTelegramSaved(false), 2000)
  }

  const Toggle = ({ cfgKey, colorClass = 'on' }) => (
    <div
      className={`toggle ${config[cfgKey] ? colorClass : 'off'}`}
      onClick={() => setConfig(p => ({ ...p, [cfgKey]: !p[cfgKey] }))}
    />
  )

  return (
    <div className="content-area" style={{ padding: '10px' }}>

      {/* Profile */}
      <HudPanel title="ПРОФІЛЬ">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 52, height: 52, borderRadius: '50%',
            background: 'rgba(0,200,255,0.15)', border: '2px solid #00c8ff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18, fontWeight: 'bold', color: '#00c8ff',
            boxShadow: '0 0 15px rgba(0,200,255,0.3)',
          }}>AF</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, color: '#a0d4ff', fontWeight: 'bold' }}>Адмін AutoFarm</div>
            <div style={{ fontSize: 9, color: '#3a5a7a', letterSpacing: '0.1em' }}>СИСТЕМНИЙ АДМІНІСТРАТОР</div>
          </div>
          <button className="btn-cyan" style={{ fontSize: 9, padding: '5px 10px' }}>РЕДАГУВАТИ</button>
        </div>
      </HudPanel>

      {/* Farm config */}
      <HudPanel title="КОНФІГУРАЦІЯ ФЕРМИ">
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4 }}>ВИД</div>
          <div style={{ fontSize: 11, color: '#8B5CF6', padding: '6px 0' }}>Cherax quadricarinatus</div>
        </div>
        {[
          { label: 'ЗАГАЛЬНА ПЛОЩА (м²)', key: 'totalArea', placeholder: '24' },
        ].map(f => (
          <div key={f.key} style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4 }}>{f.label}</div>
            <input className="hud-input" placeholder={f.placeholder}
              value={config[f.key] || ''}
              onChange={e => setConfig(p => ({ ...p, [f.key]: e.target.value }))} />
          </div>
        ))}

        {[1, 2, 3].map(n => (
          <div key={n} style={{ marginBottom: 10, padding: 10, background: 'rgba(0,10,30,0.6)', border: '1px solid rgba(0,150,255,0.15)', borderRadius: 4 }}>
            <div style={{ fontSize: 10, color: '#00c8ff', marginBottom: 8, letterSpacing: '0.1em' }}>БАСЕЙН {n}</div>
            <div style={{ marginBottom: 6 }}>
              <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 3 }}>НАЗВА</div>
              <input className="hud-input" style={{ fontSize: 11 }}
                value={config[`pool${n}Name`]}
                onChange={e => setConfig(p => ({ ...p, [`pool${n}Name`]: e.target.value }))} />
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 3 }}>ОСОБИНИ</div>
                <input className="hud-input" type="number" style={{ fontSize: 11 }}
                  value={config[`pool${n}Count`]}
                  onChange={e => setConfig(p => ({ ...p, [`pool${n}Count`]: Number(e.target.value) }))} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 3 }}>ПЛОЩА м²</div>
                <input className="hud-input" type="number" style={{ fontSize: 11 }}
                  value={config[`pool${n}Area`]}
                  onChange={e => setConfig(p => ({ ...p, [`pool${n}Area`]: Number(e.target.value) }))} />
              </div>
            </div>
          </div>
        ))}
      </HudPanel>

      {/* Telegram */}
      <HudPanel title="TELEGRAM БОТ" color={config.telegramConnected ? '#00ff88' : '#ff8c00'}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12,
          padding: '6px 10px', borderRadius: 4,
          background: config.telegramConnected ? 'rgba(0,255,136,0.05)' : 'rgba(255,140,0,0.05)',
          border: `1px solid ${config.telegramConnected ? '#00ff8833' : '#ff8c0033'}`,
        }}>
          <span className={config.telegramConnected ? 'dot-green' : 'dot-amber'} />
          <span style={{ fontSize: 11, color: config.telegramConnected ? '#00ff88' : '#ff8c00' }}>
            {config.telegramConnected ? 'ПІДКЛЮЧЕНО' : 'НЕ ПІДКЛЮЧЕНО'}
          </span>
        </div>

        {[
          { label: 'BOT TOKEN', key: 'telegramToken', type: 'password', placeholder: '1234567890:ABCdef...', hasEye: true },
          { label: 'CHAT ID', key: 'telegramChatID', type: 'text', placeholder: '-100123456789' },
          { label: "ІМ'Я БОТА", key: 'telegramBotName', type: 'text', placeholder: '@MyFarmBot' },
        ].map(f => (
          <div key={f.key} style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4 }}>{f.label}</div>
            <div style={{ position: 'relative' }}>
              <input
                className="hud-input"
                type={f.hasEye && !showToken ? 'password' : 'text'}
                placeholder={f.placeholder}
                value={config[f.key] || ''}
                onChange={e => setConfig(p => ({ ...p, [f.key]: e.target.value }))}
                style={{ paddingRight: f.hasEye ? 36 : 12 }}
              />
              {f.hasEye && (
                <button onClick={() => setShowToken(!showToken)}
                  style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: '#3a5a7a', cursor: 'pointer', fontSize: 14 }}>
                  {showToken ? '🙈' : '👁️'}
                </button>
              )}
            </div>
          </div>
        ))}

        <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
          <button className="btn-cyan" style={{ flex: 2, fontSize: 10 }} onClick={saveTelegram}>
            {telegramSaved ? '✅ ЗБЕРЕЖЕНО' : 'ЗБЕРЕГТИ'}
          </button>
          <button
            className="btn-cyan" style={{ flex: 1, fontSize: 10, opacity: config.telegramConnected ? 1 : 0.4 }}
            onClick={() => config.telegramConnected && alert('Тест надіслано!\n\n🚨 Тест AutoFarm\nБасейн 2: O₂ 7.1 mg/L ✓ НОРМА\nТемп: 27.5°C ✓ НОРМА')}
          >ТЕСТ</button>
          <button className="btn-red" style={{ flex: 1, fontSize: 10 }}
            onClick={() => setConfig(p => ({ ...p, telegramToken: '', telegramChatID: '', telegramBotName: '', telegramConnected: false }))}>
            ✕
          </button>
        </div>

        <div style={{ background: 'rgba(0,150,255,0.05)', border: '1px solid rgba(0,150,255,0.15)', borderRadius: 4, padding: 10, fontSize: 9, color: '#3a5a7a', lineHeight: 1.8 }}>
          📋 Як створити бота:<br />
          1. Відкрийте @BotFather в Telegram<br />
          2. Надішліть /newbot<br />
          3. Введіть назву та username<br />
          4. Скопіюйте токен сюди<br />
          5. Напишіть будь-що своєму боту<br />
          6. Chat ID → через @userinfobot
        </div>
      </HudPanel>

      {/* Notifications */}
      <HudPanel title="СПОВІЩЕННЯ">
        {[
          { label: '🚨 Критичні тривоги', key: null, locked: true },
          { label: '⚠️ Попередження', key: 'notifWarnings' },
          { label: '📊 Щоденний звіт 07:00', key: 'notifDaily' },
          { label: '🦞 Прогноз линяння', key: 'notifMolting' },
          { label: '🍽️ Статус годування', key: 'notifFeeding' },
          { label: '🤖 Рішення ШІ', key: 'notifAI' },
          { label: '🔒 Події безпеки', key: null, locked: true },
          { label: '🌙 Тихий режим 23:00-07:00', key: 'quietMode' },
        ].map((n, i) => (
          <div key={i} className="toggle-container">
            <span style={{ fontSize: 11, color: n.locked ? '#3a5a7a' : '#a0d4ff' }}>{n.label}</span>
            {n.locked ? (
              <div className="toggle on" style={{ cursor: 'not-allowed', opacity: 0.6 }} />
            ) : (
              <Toggle cfgKey={n.key} />
            )}
          </div>
        ))}
      </HudPanel>

      {/* Network */}
      <HudPanel title="МЕРЕЖА ТА ПІДКЛЮЧЕННЯ">
        {[
          { label: 'IP СЕРВЕРА', key: 'serverIP', placeholder: '192.168.1.xxx' },
          { label: 'ПОРТ СЕРВЕРА', key: 'serverPort', placeholder: '3000' },
          { label: 'MQTT СЕРВЕР IP', key: 'mqttIP', placeholder: '192.168.1.200' },
          { label: 'MQTT ПОРТ', key: 'mqttPort', placeholder: '1883' },
          { label: 'НАЗВА WiFi', key: 'wifiName', placeholder: 'FarmNet-5G' },
        ].map(f => (
          <div key={f.key} style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 3 }}>{f.label}</div>
            <input className="hud-input" placeholder={f.placeholder}
              value={config[f.key] || ''}
              onChange={e => setConfig(p => ({ ...p, [f.key]: e.target.value }))} />
          </div>
        ))}
        <div className="toggle-container">
          <span style={{ fontSize: 11, color: '#a0d4ff' }}>Авто-перепідключення</span>
          <Toggle cfgKey="autoReconnect" />
        </div>
        <div className="toggle-container">
          <span style={{ fontSize: 11, color: '#a0d4ff' }}>MQTT Брокер</span>
          <Toggle cfgKey="mqttEnabled" />
        </div>
      </HudPanel>

      {/* System config */}
      <HudPanel title="КОНФІГУРАЦІЯ СИСТЕМИ">
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 6, letterSpacing: '0.1em' }}>ЗБЕРІГАННЯ ЖУРНАЛУ</div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['7d', '14d', '30d', '90d'].map(v => (
              <button key={v}
                onClick={() => setConfig(p => ({ ...p, logRetention: v }))}
                style={{
                  flex: 1, padding: '7px 4px', fontSize: 10, borderRadius: 3, cursor: 'pointer',
                  background: config.logRetention === v ? 'rgba(0,200,255,0.2)' : 'rgba(0,15,40,0.5)',
                  border: `1px solid ${config.logRetention === v ? '#00c8ff' : 'rgba(0,150,255,0.2)'}`,
                  color: config.logRetention === v ? '#00c8ff' : '#3a5a7a',
                }}>{v}</button>
            ))}
          </div>
        </div>
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 6, letterSpacing: '0.1em' }}>ЧАСТОТА ОПИТУВАННЯ</div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['1s', '5s', '10s', '30s'].map(v => (
              <button key={v}
                onClick={() => setConfig(p => ({ ...p, pollInterval: v }))}
                style={{
                  flex: 1, padding: '7px 4px', fontSize: 10, borderRadius: 3, cursor: 'pointer',
                  background: config.pollInterval === v ? 'rgba(0,200,255,0.2)' : 'rgba(0,15,40,0.5)',
                  border: `1px solid ${config.pollInterval === v ? '#00c8ff' : 'rgba(0,150,255,0.2)'}`,
                  color: config.pollInterval === v ? '#00c8ff' : '#3a5a7a',
                }}>{v}</button>
            ))}
          </div>
        </div>
        <div className="toggle-container">
          <span style={{ fontSize: 11, color: '#a0d4ff' }}>🔔 Звук сповіщень</span>
          <Toggle cfgKey="soundAlerts" />
        </div>
      </HudPanel>

      {/* Security */}
      <HudPanel title="БЕЗПЕКА СИСТЕМИ" color="#ff2020">
        <div style={{ background: 'rgba(0,200,255,0.05)', border: '1px solid rgba(0,200,255,0.2)', borderRadius: 4, padding: 12, marginBottom: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 12, color: '#00c8ff' }}>🔒 БЕЗПЕКА СИСТЕМИ</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 10, color: '#00ff88' }}>
              <span className="dot-green" /> ЗАХИЩЕНО
            </span>
          </div>
          {[
            ['Активні сесії', '1'],
            ['Спроби входу (24г)', '0 ✓'],
            ['TLS Сертифікат', '87 днів'],
          ].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, padding: '3px 0', borderBottom: '1px solid rgba(0,150,255,0.1)' }}>
              <span style={{ color: '#3a5a7a' }}>{k}</span>
              <span style={{ color: '#00c8ff' }}>{v}</span>
            </div>
          ))}
          <div style={{ marginTop: 8 }}>
            <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4 }}>РЕЙТИНГ БЕЗПЕКИ</div>
            <div style={{ height: 6, background: 'rgba(0,150,255,0.1)', borderRadius: 3 }}>
              <div style={{ height: '100%', width: '94%', background: 'linear-gradient(90deg, #00ff88, #00c8ff)', borderRadius: 3 }} />
            </div>
            <div style={{ fontSize: 10, color: '#00ff88', marginTop: 2, textAlign: 'right' }}>94/100 ВІДМІННО</div>
          </div>
        </div>

        <div className="toggle-container">
          <span style={{ fontSize: 11, color: '#a0d4ff' }}>🔑 PIN захист</span>
          <Toggle cfgKey="pinEnabled" colorClass="on" />
        </div>
        <div className="toggle-container">
          <span style={{ fontSize: 11, color: '#a0d4ff' }}>📱 2FA через Telegram</span>
          <Toggle cfgKey="twoFactorEnabled" />
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <button className="btn-cyan" style={{ flex: 1, fontSize: 10 }} onClick={() => setPinModal(true)}>
            🔑 ЗМІНИТИ PIN
          </button>
          <button className="btn-cyan" style={{ flex: 1, fontSize: 10 }} onClick={() => setSecLogModal(true)}>
            📋 ЖУРНАЛ
          </button>
        </div>
        <button className="btn-red" style={{ width: '100%', marginTop: 8 }}
          onClick={() => { if (window.confirm('Активувати LOCKDOWN?')) alert('🚨 Система заблокована!\n\nДля розблокування: /unlock в Telegram боті') }}>
          🚨 LOCKDOWN
        </button>
      </HudPanel>

      {/* Coming soon */}
      <HudPanel title="НЕЗАБАРОМ" color="#3a5a7a">
        {[
          ['⚡', 'Сонячний інвертор'],
          ['🔋', 'Акумулятори'],
          ['🧪', 'pH автодозування'],
          ['🪟', 'Актуатор вікна'],
          ['📷', 'Відеоспостереження'],
          ['💡', 'Розумне освітлення'],
        ].map(([icon, label]) => (
          <div key={label}
            onClick={() => alert(`${icon} ${label}\n\nБуде доступно після підключення обладнання.\nКалібрування через цей інтерфейс.`)}
            style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '10px 0', borderBottom: '1px solid rgba(0,150,255,0.1)', cursor: 'pointer',
            }}>
            <span style={{ fontSize: 11, color: '#3a5a7a' }}>{icon} {label}</span>
            <span style={{ fontSize: 11, color: '#3a5a7a' }}>🔒 Налаштувати →</span>
          </div>
        ))}
      </HudPanel>

      {/* Themes */}
      <HudPanel title="ВІЗУАЛЬНА ТЕМА">
        {[
          { id: 'cyber_dark', name: 'Cyber Dark', desc: 'Glassmorphic dark + neon' },
          { id: 'amoled', name: 'AMOLED Black', desc: 'Pure black, battery saving' },
          { id: 'light', name: 'Clean Light', desc: 'Crisp white layout' },
        ].map(t => (
          <div key={t.id}
            onClick={() => setConfig(p => ({ ...p, theme: t.id }))}
            style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '10px', marginBottom: 6, borderRadius: 4, cursor: 'pointer',
              background: config.theme === t.id ? 'rgba(0,200,255,0.1)' : 'rgba(0,10,30,0.5)',
              border: `1px solid ${config.theme === t.id ? '#00c8ff44' : 'rgba(0,150,255,0.15)'}`,
            }}>
            <div>
              <div style={{ fontSize: 12, color: config.theme === t.id ? '#00c8ff' : '#a0d4ff' }}>{t.name}</div>
              <div style={{ fontSize: 9, color: '#3a5a7a' }}>{t.desc}</div>
            </div>
            {config.theme === t.id && (
              <span style={{ fontSize: 9, color: '#00c8ff', padding: '2px 8px', border: '1px solid #00c8ff44', borderRadius: 3 }}>АКТИВНИЙ</span>
            )}
          </div>
        ))}
      </HudPanel>

      <div style={{ textAlign: 'center', padding: '12px 0', fontSize: 9, color: '#1a2a4a' }}>
        AutoFarm OS v2.4.1 | Build 20240615 | Uptime: 14d 6h
      </div>

      {/* PIN Modal */}
      {pinModal && (
        <Modal title="ЗМІНИТИ PIN" color="#ff8c00" onClose={() => { setPinModal(false); setPinStep(1); setPin(''); setPinConfirm('') }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: '#3a5a7a', marginBottom: 16 }}>
              {pinStep === 1 ? 'Введіть новий PIN (6 цифр)' : 'Підтвердіть PIN'}
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 16 }}>
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} style={{
                  width: 32, height: 32, borderRadius: '50%',
                  background: (pinStep === 1 ? pin : pinConfirm).length > i ? 'rgba(0,200,255,0.3)' : 'rgba(0,15,40,0.5)',
                  border: `2px solid ${(pinStep === 1 ? pin : pinConfirm).length > i ? '#00c8ff' : 'rgba(0,150,255,0.3)'}`,
                  boxShadow: (pinStep === 1 ? pin : pinConfirm).length > i ? '0 0 8px #00c8ff' : 'none',
                }} />
              ))}
            </div>
            <input
              className="hud-input" type="password" maxLength={6}
              placeholder="••••••"
              style={{ textAlign: 'center', letterSpacing: '0.5em', fontSize: 18, marginBottom: 12 }}
              value={pinStep === 1 ? pin : pinConfirm}
              onChange={e => pinStep === 1 ? setPin(e.target.value) : setPinConfirm(e.target.value)}
            />
            <button className="btn-cyan" style={{ width: '100%' }}
              onClick={() => {
                if (pinStep === 1) { if (pin.length === 6) setPinStep(2) }
                else {
                  if (pin === pinConfirm) {
                    alert('✅ PIN змінено!\nПовідомлення надіслано в Telegram.')
                    setPinModal(false); setPinStep(1); setPin(''); setPinConfirm('')
                  } else {
                    alert('PIN не співпадає!')
                    setPinConfirm('')
                  }
                }
              }}>
              {pinStep === 1 ? 'ДАЛІ' : 'ЗБЕРЕГТИ PIN'}
            </button>
            <div style={{ fontSize: 9, color: '#3a5a7a', marginTop: 8 }}>
              PIN буде надіслано для підтвердження через Telegram
            </div>
          </div>
        </Modal>
      )}

      {/* Security log modal */}
      {secLogModal && (
        <Modal title="ЖУРНАЛ БЕЗПЕКИ" onClose={() => setSecLogModal(false)}>
          {securityLogs.map((log, i) => (
            <div key={i} style={{
              padding: '8px 0', borderBottom: '1px solid rgba(0,150,255,0.1)',
              display: 'flex', gap: 8,
            }}>
              <span style={{
                fontSize: 9, padding: '2px 6px', borderRadius: 3, flexShrink: 0, height: 'fit-content',
                background: log.type === 'LOGIN_FAIL' ? 'rgba(255,32,32,0.1)' : 'rgba(0,200,255,0.1)',
                border: `1px solid ${log.type === 'LOGIN_FAIL' ? '#ff202033' : '#00c8ff33'}`,
                color: log.type === 'LOGIN_FAIL' ? '#ff2020' : '#00c8ff',
              }}>{log.type}</span>
              <div>
                <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 2 }}>{log.time}</div>
                <div style={{ fontSize: 10, color: '#a0d4ff' }}>{log.detail}</div>
              </div>
            </div>
          ))}
        </Modal>
      )}
    </div>
  )
}
