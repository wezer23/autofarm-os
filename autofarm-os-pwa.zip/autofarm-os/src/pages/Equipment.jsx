import React, { useState } from 'react'
import HudPanel from '../components/HudPanel'
import Modal from '../components/Modal'

export default function Equipment({ config, setConfig }) {
  const [pingModal, setPingModal] = useState(null)
  const [rebootModal, setRebootModal] = useState(null)
  const [rebooting, setRebooting] = useState(false)
  const [calTab, setCalTab] = useState('temp')
  const [gpioOpen, setGpioOpen] = useState(false)
  const [gpio, setGpio] = useState([
    { pin: 'IN1 (GPIO 19)', label: 'Освітлення басейнів', active: false },
    { pin: 'IN2 (GPIO 18)', label: 'Приплив вентиляції', active: true },
    { pin: 'IN3 (GPIO 17)', label: 'Витяжка вентиляції', active: true },
    { pin: 'IN4 (GPIO 16)', label: 'Аерація Басейн 1', active: true },
    { pin: 'IN5 (GPIO 15)', label: 'Аерація Басейн 2', active: true },
    { pin: 'IN6 (GPIO 14)', label: 'Аерація Басейн 3', active: true },
    { pin: 'IN7 (GPIO 13)', label: 'Годівниця', active: false },
    { pin: 'IN8 (GPIO 12)', label: 'Резерв', active: false },
  ])

  const nodes = [
    {
      id: 'A', name: 'Контролер Басейнів', node: 'ESP32-NODE-A',
      ipKey: 'nodeA_IP', online: true, signal: '-42 dBm',
      metrics: [
        { label: 'ТЕМП.ВОДИ', value: config.waterTemp.toFixed(1), unit: '°C' },
        { label: 'КИСЕНЬ', value: config.oxygen.toFixed(1), unit: 'mg/L' },
        { label: 'pH', value: config.pH.toFixed(1), unit: '' },
      ]
    },
    {
      id: 'B', name: 'Контролер Клімату', node: 'ESP32-NODE-B',
      ipKey: 'nodeB_IP', online: true, signal: '-67 dBm',
      metrics: [
        { label: 'ТЕМП.ПОВІТРЯ', value: config.airTemp.toFixed(1), unit: '°C' },
        { label: 'ВОЛОГІСТЬ', value: config.humidity, unit: '%' },
        { label: 'АМІАК', value: config.ammonia.toFixed(3), unit: 'mg/L' },
      ]
    },
    {
      id: 'C', name: 'Контролер Освітлення', node: 'ESP32-NODE-C',
      ipKey: 'nodeC_IP', online: false, signal: 'N/A',
      metrics: []
    },
  ]

  const handlePing = (node) => {
    setPingModal(node)
  }

  const handleReboot = (node) => {
    setRebootModal(node)
  }

  const confirmReboot = () => {
    setRebooting(true)
    setTimeout(() => {
      setRebooting(false)
      setRebootModal(null)
    }, 3000)
  }

  const calConfig = {
    temp: { key: 'tempOffset', label: 'ТЕМПЕРАТУРА', min: -2, max: 2, step: 0.1, unit: '°C', raw: 27.3 },
    o2: { key: 'o2Offset', label: 'КИСЕНЬ O₂', min: -1, max: 1, step: 0.1, unit: 'mg/L', raw: 7.0 },
    ph: { key: 'phOffset', label: 'pH', min: -0.5, max: 0.5, step: 0.1, unit: '', raw: 7.7 },
  }

  return (
    <div className="content-area" style={{ padding: '10px' }}>
      {/* Server connection */}
      <HudPanel title="ПІДКЛЮЧЕННЯ СЕРВЕРА" color={config.serverIP ? '#00ff88' : '#ff8c00'}>
        {!config.serverIP && (
          <div style={{ background: 'rgba(255,140,0,0.1)', border: '1px solid #ff8c0033', borderRadius: 4, padding: '6px 10px', marginBottom: 10 }}>
            <span style={{ fontSize: 10, color: '#ff8c00' }}>⚠️ Сервер не налаштовано</span>
          </div>
        )}
        <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4, letterSpacing: '0.1em' }}>IP АДРЕСА</div>
            <input className="hud-input" placeholder="192.168.1.xxx"
              value={config.serverIP}
              onChange={e => setConfig(p => ({ ...p, serverIP: e.target.value }))} />
          </div>
          <div style={{ width: 80 }}>
            <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4, letterSpacing: '0.1em' }}>ПОРТ</div>
            <input className="hud-input" placeholder="3000"
              value={config.serverPort}
              onChange={e => setConfig(p => ({ ...p, serverPort: e.target.value }))} />
          </div>
        </div>
        <div style={{ marginBottom: 10 }}>
          <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4 }}>API TOKEN</div>
          <input className="hud-input" type="password" placeholder="Bearer token..."
            value={config.apiToken || ''}
            onChange={e => setConfig(p => ({ ...p, apiToken: e.target.value }))} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 10, color: config.serverIP ? '#00ff88' : '#3a5a7a' }}>
            {config.serverIP ? '● Налаштовано' : '○ Не налаштовано'}
          </span>
          <button className="btn-cyan" style={{ fontSize: 10, padding: '6px 12px' }}
            onClick={() => alert('Підключення: OK (симуляція)')}>
            ПЕРЕВІРИТИ
          </button>
        </div>
      </HudPanel>

      {/* ESP32 Integration */}
      <HudPanel title="ІНТЕГРАЦІЯ ESP32">
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4, letterSpacing: '0.1em' }}>ENDPOINT POST</div>
          <div style={{
            background: '#000810', border: '1px solid rgba(0,150,255,0.2)',
            borderRadius: 4, padding: '8px 10px', fontSize: 10, color: '#00c8ff',
            wordBreak: 'break-all',
          }}>
            http://{config.serverIP || 'YOUR-IP'}:{config.serverPort}/api/hardware/update
          </div>
        </div>
        <div style={{ background: '#000810', border: '1px solid rgba(0,150,255,0.2)', borderRadius: 4, padding: 8, marginBottom: 8 }}>
          <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 6 }}>JSON ДАНІ:</div>
          <pre style={{ fontSize: 10, color: '#00ff88', overflow: 'auto' }}>{`{
  "nodeId": "NODE-A",
  "waterTemp": ${config.waterTemp.toFixed(1)},
  "o2": ${config.oxygen.toFixed(1)},
  "pH": ${config.pH.toFixed(1)},
  "ammonia": ${config.ammonia.toFixed(3)},
  "humidity": ${config.humidity},
  "airTemp": ${config.airTemp.toFixed(1)}
}`}</pre>
        </div>
        <div style={{ fontSize: 9, color: '#3a5a7a', padding: '4px 0' }}>
          📌 DS18B20: GPIO 4 + резистор 4.7кОм між DATA і 3.3V
        </div>
      </HudPanel>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 10 }}>
        {[['2', 'Активні'], ['12', 'Датчики'], ['0', 'Тривоги']].map(([v, l], i) => (
          <div key={i} style={{ textAlign: 'center', background: 'rgba(0,15,40,0.8)', border: '1px solid rgba(0,150,255,0.2)', borderRadius: 4, padding: 10 }}>
            <div style={{ fontSize: 22, color: '#00c8ff', fontWeight: 'bold', textShadow: '0 0 8px #00c8ff' }}>{v}</div>
            <div style={{ fontSize: 9, color: '#3a5a7a' }}>{l}</div>
          </div>
        ))}
      </div>

      {/* Node cards */}
      {nodes.map(node => (
        <div key={node.id} className="hud-panel" style={{
          marginBottom: 10, padding: 12,
          borderColor: node.online ? 'rgba(0,255,136,0.3)' : 'rgba(255,32,32,0.3)',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span className={node.online ? 'dot-green' : 'dot-red'} />
              <div>
                <div style={{ fontSize: 12, color: '#a0d4ff', fontWeight: 'bold' }}>{node.name}</div>
                <div style={{ fontSize: 9, color: '#3a5a7a' }}>{node.node}</div>
              </div>
            </div>
            <span style={{
              fontSize: 10, padding: '3px 8px', borderRadius: 3,
              background: node.online ? 'rgba(0,255,136,0.1)' : 'rgba(255,32,32,0.1)',
              border: `1px solid ${node.online ? '#00ff8844' : '#ff202044'}`,
              color: node.online ? '#00ff88' : '#ff2020',
            }}>{node.online ? 'ONLINE' : 'OFFLINE'}</span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 10 }}>
            <div>
              <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4 }}>IP АДРЕСА</div>
              <input className="hud-input" style={{ fontSize: 11 }}
                value={config[node.ipKey]}
                onChange={e => setConfig(p => ({ ...p, [node.ipKey]: e.target.value }))} />
            </div>
            <div>
              <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4 }}>СИГНАЛ</div>
              <div style={{ fontSize: 12, color: node.online ? '#00c8ff' : '#3a5a7a', padding: '8px 0' }}>{node.signal}</div>
            </div>
          </div>

          {node.online && node.metrics.length > 0 && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6, marginBottom: 10 }}>
              {node.metrics.map((m, i) => (
                <div key={i} style={{ textAlign: 'center', background: 'rgba(0,10,30,0.6)', borderRadius: 4, padding: '6px 4px' }}>
                  <div style={{ fontSize: 8, color: '#3a5a7a', marginBottom: 2 }}>{m.label}</div>
                  <div style={{ fontSize: 14, color: '#00c8ff', fontWeight: 'bold' }}>{m.value}</div>
                  <div style={{ fontSize: 8, color: '#3a5a7a' }}>{m.unit}</div>
                </div>
              ))}
            </div>
          )}

          {!node.online && (
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 10, color: '#ff2020', marginBottom: 8 }}>ОФЛАЙН: 2г 14хв тому</div>
              <button className="btn-cyan" style={{ width: '100%' }}
                onClick={() => alert('Підключення...')}>
                📡 ПІДКЛЮЧИТИСЬ
              </button>
            </div>
          )}

          {node.online && (
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn-cyan" style={{ flex: 1, fontSize: 11 }}
                onClick={() => handlePing(node)}>⚡ ПІНГ</button>
              <button className="btn-red" style={{ flex: 1, fontSize: 11 }}
                onClick={() => handleReboot(node)}>🔄 ПЕРЕЗАВАНТ.</button>
            </div>
          )}
        </div>
      ))}

      {/* Calibration */}
      <HudPanel title="КАЛІБРУВАННЯ ДАТЧИКІВ">
        <div style={{ display: 'flex', gap: 4, marginBottom: 12 }}>
          {Object.entries(calConfig).map(([key, val]) => (
            <button key={key}
              onClick={() => setCalTab(key)}
              style={{
                flex: 1, padding: '6px 4px', fontSize: 9, letterSpacing: '0.1em',
                background: calTab === key ? 'rgba(0,200,255,0.2)' : 'rgba(0,15,40,0.5)',
                border: `1px solid ${calTab === key ? '#00c8ff' : 'rgba(0,150,255,0.2)'}`,
                color: calTab === key ? '#00c8ff' : '#3a5a7a',
                borderRadius: 3, cursor: 'pointer',
              }}>
              {val.label}
            </button>
          ))}
        </div>
        {(() => {
          const c = calConfig[calTab]
          const offset = config[c.key] || 0
          return (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 10, color: '#3a5a7a' }}>ЗМІЩЕННЯ</span>
                <span style={{ fontSize: 12, color: '#00c8ff' }}>{offset >= 0 ? '+' : ''}{offset.toFixed(1)} {c.unit}</span>
              </div>
              <input type="range" min={c.min} max={c.max} step={c.step}
                value={offset}
                onChange={e => setConfig(p => ({ ...p, [c.key]: Number(e.target.value) }))} />
              <div style={{ fontSize: 10, color: '#3a5a7a', marginTop: 6 }}>
                Сирі: {c.raw}{c.unit} → Скориговані: <span style={{ color: '#00ff88' }}>{(c.raw + offset).toFixed(1)}{c.unit}</span>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                <button className="btn-cyan" style={{ flex: 1, fontSize: 10 }}
                  onClick={() => setConfig(p => ({ ...p, [c.key]: 0 }))}>СКИНУТИ</button>
                <button className="btn-cyan" style={{ flex: 1, fontSize: 10 }}
                  onClick={() => alert('Збережено!')}>ЗБЕРЕГТИ</button>
              </div>
            </div>
          )
        })()}
      </HudPanel>

      {/* GPIO */}
      <HudPanel title="КАРТА ВИВОДІВ GPIO">
        <button
          onClick={() => setGpioOpen(!gpioOpen)}
          style={{ background: 'none', border: 'none', color: '#3a5a7a', fontSize: 11, cursor: 'pointer', marginBottom: gpioOpen ? 10 : 0 }}
        >
          {gpioOpen ? '▲ Сховати' : '▼ Показати GPIO'}
        </button>
        {gpioOpen && gpio.map((g, i) => (
          <div key={i} className="toggle-container">
            <div>
              <div style={{ fontSize: 10, color: '#00c8ff' }}>{g.pin}</div>
              <div style={{ fontSize: 9, color: '#3a5a7a' }}>{g.label}</div>
            </div>
            <div
              className={`toggle ${g.active ? 'on' : 'off'}`}
              onClick={() => setGpio(prev => prev.map((x, j) => j === i ? { ...x, active: !x.active } : x))}
            />
          </div>
        ))}
      </HudPanel>

      {/* Ping modal */}
      {pingModal && (
        <Modal title="PING РЕЗУЛЬТАТ" onClose={() => setPingModal(null)}>
          <div style={{ textAlign: 'center', padding: 20 }}>
            <div style={{ fontSize: 40, marginBottom: 10 }}>⚡</div>
            <div style={{ fontSize: 14, color: '#00ff88', marginBottom: 6 }}>{pingModal.name}</div>
            <div style={{ fontSize: 22, color: '#00c8ff', fontWeight: 'bold' }}>12ms</div>
            <div style={{ fontSize: 12, color: '#00ff88', marginTop: 4 }}>✓ ВІДПОВІДЬ ОТРИМАНА</div>
          </div>
        </Modal>
      )}

      {/* Reboot modal */}
      {rebootModal && (
        <Modal title="ПІДТВЕРДЖЕННЯ ПЕРЕЗАВАНТАЖЕННЯ" color="#ff2020" onClose={() => setRebootModal(null)}>
          <div style={{ textAlign: 'center', padding: '10px 0' }}>
            {rebooting ? (
              <>
                <div style={{ fontSize: 30, marginBottom: 10, animation: 'spin 1s linear infinite', display: 'inline-block' }}>🔄</div>
                <div style={{ color: '#ff8c00', fontSize: 12 }}>Перезавантаження...</div>
                <div style={{ color: '#3a5a7a', fontSize: 10, marginTop: 4 }}>Очікуйте ~8 секунд</div>
              </>
            ) : (
              <>
                <div style={{ fontSize: 12, color: '#a0d4ff', marginBottom: 16 }}>
                  Перезавантажити <span style={{ color: '#ff8c00' }}>{rebootModal.name}</span>?
                </div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button className="btn-red" style={{ flex: 1 }} onClick={confirmReboot}>✓ ТАК</button>
                  <button className="btn-cyan" style={{ flex: 1 }} onClick={() => setRebootModal(null)}>✕ НІ</button>
                </div>
              </>
            )}
          </div>
        </Modal>
      )}
    </div>
  )
}
