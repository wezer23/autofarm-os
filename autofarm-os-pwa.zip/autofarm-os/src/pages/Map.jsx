import React, { useState } from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import HudPanel from '../components/HudPanel'
import Modal from '../components/Modal'

const mockHistory = Array.from({ length: 24 }, (_, i) => ({
  h: `${i}:00`,
  temp: 27 + Math.sin(i / 4) * 0.8 + Math.random() * 0.3,
  o2: 7 + Math.sin(i / 6) * 0.5 + Math.random() * 0.2,
}))

export default function Map({ config }) {
  const [selectedZone, setSelectedZone] = useState(null)

  const pools = [
    {
      id: 1, name: config.pool1Name, stage: 'Молодь',
      count: config.pool1Count, area: config.pool1Area,
      zones: ['П1-1', 'П1-2', 'П1-3'],
      color: '#00ff88',
    },
    {
      id: 2, name: config.pool2Name, stage: 'Вирощування',
      count: config.pool2Count, area: config.pool2Area,
      zones: ['П2-1', 'П2-2', 'П2-3'],
      color: '#00c8ff',
    },
    {
      id: 3, name: config.pool3Name, stage: 'Товарні',
      count: config.pool3Count, area: config.pool3Area,
      zones: ['П3-1', 'П3-2', null],
      color: '#8B5CF6',
    },
  ]

  return (
    <div className="content-area" style={{ padding: '10px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12, padding: '0 4px' }}>
        <div style={{ fontSize: 11, color: '#00c8ff', letterSpacing: '0.2em' }}>КАРТА ФЕРМИ</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className="dot-green" />
          <span style={{ fontSize: 9, color: '#00ff88' }}>Всі норма</span>
        </div>
      </div>

      {pools.map(pool => (
        <div key={pool.id} className="hud-panel" style={{ marginBottom: 12, padding: 12, borderColor: pool.color + '44' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 16 }}>🦞</span>
              <div>
                <div style={{ fontSize: 12, color: '#a0d4ff', fontWeight: 'bold' }}>{pool.name}</div>
                <div style={{ fontSize: 9, color: '#3a5a7a' }}>{pool.stage}</div>
              </div>
            </div>
            <span style={{
              fontSize: 9, padding: '3px 8px', borderRadius: 3,
              background: pool.color + '22', border: `1px solid ${pool.color}44`,
              color: pool.color,
            }}>НОРМА</span>
          </div>

          <div style={{ display: 'flex', gap: 12, marginBottom: 10 }}>
            <span style={{ fontSize: 10, color: '#3a5a7a' }}>🦞 {pool.count} особин</span>
            <span style={{ fontSize: 10, color: '#3a5a7a' }}>📐 {pool.area}м²</span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6 }}>
            {pool.zones.map((zone, i) => (
              zone ? (
                <button key={i}
                  onClick={() => setSelectedZone({ zone, pool })}
                  style={{
                    background: 'rgba(0,10,30,0.8)',
                    border: `1px solid ${pool.color}44`,
                    borderRadius: 6, padding: '10px 6px',
                    textAlign: 'center', cursor: 'pointer',
                    transition: 'all 0.2s',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 9, color: '#3a5a7a' }}>{zone}</span>
                    <span className="dot-green" style={{ width: 6, height: 6 }} />
                  </div>
                  <div style={{ fontSize: 16, marginBottom: 4 }}>🦞</div>
                  <div style={{ fontSize: 13, fontWeight: 'bold', color: pool.color }}>
                    {config.waterTemp.toFixed(1)}°
                  </div>
                  <div style={{ fontSize: 8, color: '#3a5a7a' }}>H₂O</div>
                </button>
              ) : (
                <div key={i} style={{
                  background: 'rgba(0,5,15,0.5)',
                  border: '1px solid rgba(50,50,80,0.5)',
                  borderRadius: 6, padding: '10px 6px',
                  textAlign: 'center', opacity: 0.5,
                }}>
                  <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 8 }}>П{pool.id}-3</div>
                  <div style={{ fontSize: 16, marginBottom: 4 }}>🔧</div>
                  <div style={{ fontSize: 9, color: '#3a5a7a' }}>ВІДКЛЮЧЕНО</div>
                </div>
              )
            ))}
          </div>
        </div>
      ))}

      {/* Matrix */}
      <HudPanel title="МАТРИЦЯ ЗОН ФЕРМИ">
        {[
          { name: 'ВУЗОЛ-А: Басейни Раків', node: 'ESP32-NODE-A', zones: ['П1-1', 'П1-2', 'П2-1', 'П2-2', 'П3-1'] },
          { name: 'ВУЗОЛ-Б: Клімат/Моніт.', node: 'ESP32-NODE-B', zones: ['П1-3', 'П2-3'] },
        ].map((n, i) => (
          <div key={i} style={{
            background: 'rgba(0,10,30,0.6)', border: '1px solid rgba(0,255,136,0.2)',
            borderRadius: 6, padding: 10, marginBottom: 8,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <div>
                <div style={{ fontSize: 11, color: '#a0d4ff' }}>{n.name}</div>
                <div style={{ fontSize: 9, color: '#3a5a7a' }}>{n.node}</div>
              </div>
              <span style={{ fontSize: 9, color: '#00ff88', padding: '2px 6px', border: '1px solid #00ff8844', borderRadius: 3 }}>NOMINAL</span>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {n.zones.map(z => (
                <span key={z} style={{
                  fontSize: 10, padding: '3px 8px', borderRadius: 3,
                  background: 'rgba(0,200,255,0.1)', border: '1px solid rgba(0,200,255,0.3)',
                  color: '#00c8ff', cursor: 'pointer',
                }}>{z} ›</span>
              ))}
            </div>
          </div>
        ))}
      </HudPanel>

      {/* Zone detail modal */}
      {selectedZone && (
        <Modal title={`ЗОНА ${selectedZone.zone}`} onClose={() => setSelectedZone(null)}>
          <div>
            <div style={{ fontSize: 10, color: '#3a5a7a', marginBottom: 12 }}>
              {selectedZone.pool.name} — {selectedZone.pool.stage}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 8, marginBottom: 14 }}>
              {[
                { label: 'Температура', value: config.waterTemp.toFixed(1), unit: '°C', color: '#00c8ff' },
                { label: 'Кисень', value: config.oxygen.toFixed(1), unit: 'mg/L', color: '#00ff88' },
                { label: 'pH', value: config.pH.toFixed(1), unit: '', color: '#8B5CF6' },
                { label: 'Аміак', value: config.ammonia.toFixed(3), unit: 'mg/L', color: '#ff8c00' },
              ].map((m, i) => (
                <div key={i} style={{ background: 'rgba(0,10,30,0.8)', border: '1px solid rgba(0,150,255,0.2)', borderRadius: 4, padding: 8, textAlign: 'center' }}>
                  <div style={{ fontSize: 8, color: '#3a5a7a', marginBottom: 4 }}>{m.label}</div>
                  <div style={{ fontSize: 18, color: m.color, fontWeight: 'bold' }}>{m.value}</div>
                  <div style={{ fontSize: 8, color: '#3a5a7a' }}>{m.unit}</div>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 10, color: '#3a5a7a', marginBottom: 6, letterSpacing: '0.1em' }}>ТЕМПЕРАТУРА 24Г</div>
            <ResponsiveContainer width="100%" height={120}>
              <LineChart data={mockHistory}>
                <XAxis dataKey="h" tick={{ fill: '#3a5a7a', fontSize: 8 }} />
                <YAxis domain={[26, 29]} tick={{ fill: '#3a5a7a', fontSize: 8 }} />
                <Tooltip contentStyle={{ background: '#000d1a', border: '1px solid #00c8ff44', fontSize: 10 }} />
                <Line type="monotone" dataKey="temp" stroke="#00c8ff" dot={false} strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Modal>
      )}
    </div>
  )
}
