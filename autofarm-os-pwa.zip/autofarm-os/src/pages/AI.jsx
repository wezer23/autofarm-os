import React, { useState, useRef, useEffect } from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'
import ArcReactor from '../components/ArcReactor'
import HudPanel from '../components/HudPanel'
import Modal from '../components/Modal'
import SensorCard from '../components/SensorCard'

const biomassData = Array.from({ length: 90 }, (_, i) => ({
  day: i + 1,
  biomass: 15 + i * 0.18 + Math.sin(i / 7) * 0.5,
  molt: i % 28 < 3 ? 15 + i * 0.18 : null,
}))

const chatResponses = {
  'температур': (c) => `Температура води ${c.waterTemp.toFixed(1)}°C — ідеальний режим 27-28.5°C. За 24г: min 27.1°C, max 27.9°C.`,
  'кисень': (c) => `Кисень ${c.oxygen.toFixed(1)} mg/L — норма (>7.0). При 28°C кисень розчиняється важко, аерація активна.`,
  'ph': (c) => `pH ${c.pH.toFixed(1)} — оптимальна зона 7.5-8.5. Норма.`,
  'аміак': (c) => `Аміак ${c.ammonia.toFixed(3)} mg/L — безпечний рівень (<0.05). Відходи раків під контролем.`,
  'вологість': (c) => `Вологість ${c.humidity}% — ${c.humidity > 75 ? 'підвищена, збільшіть вентиляцію' : 'норма'}. Вентиляція ${c.intakeFanSpeed}%.`,
  'линяння': () => `Прогноз линяння: Басейн 2 через ~3 дні. Підготуйте укриття (3D-трубки). Кальцієвий корм після линьки.`,
  'збір': () => `Басейн 3 готовий до збору ~11 днів. Очікувана маса: ~18кг товарних раків (~180г кожен).`,
  'годів': (c) => `Годування: 2x день (06:00 і 18:00). При ${c.waterTemp.toFixed(1)}°C — ${c.waterTemp > 27 ? 'максимальний' : 'знижений'} метаболізм.`,
  'справи': (c) => `Все відмінно, сер! 3 басейни активні, 275 раків ростуть. Температура ${c.waterTemp.toFixed(1)}°C, кисень норма.`,
  'прогноз': () => `7-денний прогноз: температура стабільна 27-28°C, линяння Басейн 2 (~3 дні), збір Басейн 3 (~11 днів).`,
  'стоп': () => `⚠️ Команда СТОП отримана. Переключаю в режим РУЧНИЙ. Всі актуатори зупинено.`,
}

const defaultResponse = () => `Уточніть, будь ласка. Я можу розповісти про температуру, кисень, pH, аміак, вологість, годівлю, линяння або прогнози.`

export default function AIPage({ config, setConfig }) {
  const [testModal, setTestModal] = useState(false)
  const [testStep, setTestStep] = useState(0)
  const [trainModal, setTrainModal] = useState(false)
  const [reportModal, setReportModal] = useState(false)
  const [chatMessages, setChatMessages] = useState([
    { from: 'ai', text: 'Доброго дня, сер! Ферма в нормі. 3 басейни активні. Лиска в Басейні 2 очікується через ~3 дні. Готовий до роботи.' }
  ])
  const [chatInput, setChatInput] = useState('')
  const chatRef = useRef(null)
  const [trainData, setTrainData] = useState({ pool: '1', weight: '', health: 3, stage: 'норма', count: '' })

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight
  }, [chatMessages])

  const runTest = () => {
    setTestModal(true)
    setTestStep(0)
    const steps = [1, 2, 3, 4, 5]
    steps.forEach((_, i) => {
      setTimeout(() => setTestStep(i + 1), (i + 1) * 800)
    })
  }

  const sendChat = (text) => {
    if (!text.trim()) return
    setChatMessages(prev => [...prev, { from: 'user', text }])
    setChatInput('')
    setTimeout(() => {
      const t = text.toLowerCase()
      let response = defaultResponse()
      for (const [key, fn] of Object.entries(chatResponses)) {
        if (t.includes(key)) { response = fn(config); break }
      }
      setChatMessages(prev => [...prev, { from: 'ai', text: response }])
    }, 600)
  }

  const protocols = [
    { key: 'proto_o2', label: 'Аварійна Відповідь на O₂', conf: 99.8, locked: true, color: 'red' },
    { key: 'proto_thermal', label: 'Термічний Контроль 28°C', conf: 97.4, locked: false, color: 'purple' },
    { key: 'proto_feeding', label: 'Оптимізатор Годівлі Cherax', conf: 91.2, locked: false, color: 'purple' },
    { key: 'proto_molting', label: 'Протокол Линяння Cherax', conf: 88.6, locked: false, color: 'off' },
    { key: 'proto_humidity', label: 'Контроль Вологості', conf: 94.1, locked: false, color: 'off' },
    { key: 'proto_growth', label: 'ШІ Оптимізації Росту', conf: 76.3, locked: false, color: 'off' },
  ]

  const testSteps = ['Перевірка датчиків', 'Перевірка насосів', 'Перевірка аерації', 'Перевірка годівниці', 'Перевірка освітлення']

  const getStatus = (val, min, max) => val < min || val > max ? 'critical' : 'normal'

  return (
    <div className="content-area hex-bg" style={{ padding: '10px' }}>

      {/* JARVIS Header */}
      <div className="hud-panel" style={{
        padding: '20px 16px', marginBottom: 10,
        background: 'linear-gradient(135deg, rgba(0,15,50,0.9), rgba(20,0,60,0.9))',
        borderColor: '#8B5CF6aa',
        textAlign: 'center',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 12 }}>
          <ArcReactor size={70} status={config.proto_o2 ? 'normal' : 'offline'} />
        </div>
        <div style={{ fontSize: 14, color: '#00c8ff', letterSpacing: '0.2em', fontWeight: 'bold', marginBottom: 4 }}>
          J.A.R.V.I.S. — AutoFarm Edition
        </div>
        <div style={{ fontSize: 9, color: '#8B5CF6', letterSpacing: '0.15em', marginBottom: 10 }}>
          Just A Rather Very Intelligent System
        </div>
        <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 12 }}>
          MODEL: AutoFarm-NLP-v4 | UPTIME: 14D 6H 12M
        </div>

        {/* Mode selector */}
        <div style={{ display: 'flex', gap: 6 }}>
          {['РУЧНИЙ', 'АСИСТОВАНИЙ', 'АВТОНОМНИЙ'].map(mode => (
            <button key={mode}
              onClick={() => setConfig(p => ({ ...p, aiMode: mode }))}
              style={{
                flex: 1, padding: '7px 4px', fontSize: 9, letterSpacing: '0.05em',
                background: config.aiMode === mode ? 'rgba(139,92,246,0.3)' : 'rgba(0,15,40,0.5)',
                border: `1px solid ${config.aiMode === mode ? '#8B5CF6' : 'rgba(0,150,255,0.2)'}`,
                color: config.aiMode === mode ? '#8B5CF6' : '#3a5a7a',
                borderRadius: 4, cursor: 'pointer',
                boxShadow: config.aiMode === mode ? '0 0 10px rgba(139,92,246,0.4)' : 'none',
              }}>
              {mode}
            </button>
          ))}
        </div>
        <div style={{ marginTop: 8, fontSize: 10, color: '#a0d4ff', opacity: 0.7 }}>
          {config.aiMode === 'АВТОНОМНИЙ' ? 'ШІ управляє всіма системами. Аварійне управління увімкнено.' :
           config.aiMode === 'АСИСТОВАНИЙ' ? 'ШІ рекомендує — людина вирішує.' :
           'Ручне керування всіма системами.'}
        </div>
      </div>

      {/* Sensors */}
      <HudPanel title="СТАН ДАТЧИКІВ — LIVE">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8 }}>
          <SensorCard label="ТЕМП.ВОДИ" value={config.waterTemp.toFixed(1)} unit="°C"
            status={getStatus(config.waterTemp, config.tempMin, config.tempMax)} />
          <SensorCard label="КИСЕНЬ" value={config.oxygen.toFixed(1)} unit="mg/L"
            status={getStatus(config.oxygen, config.o2Min, 12)} />
          <SensorCard label="pH" value={config.pH.toFixed(1)} unit="НОРМА" status="normal" />
          <SensorCard label="АМІАК" value={config.ammonia.toFixed(3)} unit="mg/L"
            status={config.ammonia > config.ammoniaMax ? 'critical' : 'normal'} />
          <SensorCard label="ВОЛОГІСТЬ" value={config.humidity} unit="%"
            status={config.humidity > 85 ? 'critical' : config.humidity > 75 ? 'warning' : 'normal'} />
          <SensorCard label="ТЕМП.ПОВІТРЯ" value={config.airTemp.toFixed(1)} unit="°C" status="normal" />
        </div>
      </HudPanel>

      {/* Protocols */}
      <HudPanel title="НЕЙРОННІ ПРОТОКОЛИ">
        {protocols.map(p => {
          const isOn = config[p.key]
          const toggleClass = p.locked ? 'on-red' : isOn ? 'on-purple' : 'off'
          return (
            <div key={p.key} className="toggle-container">
              <div style={{ flex: 1, marginRight: 10 }}>
                <div style={{ fontSize: 11, color: '#a0d4ff' }}>
                  {p.locked && <span style={{ color: '#ff2020', marginRight: 4 }}>🔴</span>}
                  {p.label}
                </div>
                <div style={{ fontSize: 9, color: '#3a5a7a', marginTop: 2 }}>
                  Впевн: <span style={{ color: isOn || p.locked ? '#00ff88' : '#3a5a7a' }}>{p.conf}%</span>
                  {(isOn || p.locked) && <span style={{ color: '#00ff88', marginLeft: 6 }}>● АКТИВНИЙ</span>}
                </div>
                <div style={{ height: 2, background: 'rgba(0,150,255,0.1)', borderRadius: 1, marginTop: 4 }}>
                  <div style={{ height: '100%', width: `${p.conf}%`, background: p.locked ? '#ff2020' : isOn ? '#8B5CF6' : '#3a5a7a', borderRadius: 1 }} />
                </div>
              </div>
              <div
                className={`toggle ${toggleClass}`}
                onClick={() => !p.locked && setConfig(prev => ({ ...prev, [p.key]: !prev[p.key] }))}
                style={{ cursor: p.locked ? 'not-allowed' : 'pointer', opacity: p.locked ? 0.7 : 1 }}
              />
            </div>
          )
        })}
      </HudPanel>

      {/* Thresholds */}
      <HudPanel title="ПОРОГОВІ ЗНАЧЕННЯ">
        {[
          { label: 'Мінімум O₂', key: 'o2Min', min: 0, max: 10, unit: 'mg/L', current: config.oxygen, currentLabel: 'O₂' },
          { label: 'Максимум Темп.', key: 'tempMax', min: 0, max: 40, unit: '°C', current: config.waterTemp, currentLabel: 'Темп' },
        ].map(t => (
          <div key={t.key} style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ fontSize: 11, color: '#a0d4ff' }}>{t.label}</span>
              <span style={{ fontSize: 14, fontWeight: 'bold', color: '#00c8ff' }}>
                {config[t.key]} {t.unit}
              </span>
            </div>
            <input type="range" min={t.min} max={t.max} step="0.5"
              value={config[t.key]}
              onChange={e => setConfig(p => ({ ...p, [t.key]: Number(e.target.value) }))} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
              <span style={{ fontSize: 9, color: '#3a5a7a' }}>{t.min} {t.unit}</span>
              <span style={{ fontSize: 9, color: '#00ff88' }}>
                Поточний {t.currentLabel}: {t.current.toFixed(1)} {t.unit} ✓ НОРМА
              </span>
              <span style={{ fontSize: 9, color: '#3a5a7a' }}>{t.max} {t.unit}</span>
            </div>
          </div>
        ))}
        <button className="btn-red" style={{ width: '100%', marginTop: 4 }} onClick={runTest}>
          ⚡ ТЕСТ УПРАВЛІННЯ
        </button>
      </HudPanel>

      {/* 90-day predictions */}
      <HudPanel title="ПРОГНОЗ БІОМАСИ 90 ДНІВ" color="#8B5CF6">
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={biomassData}>
            <XAxis dataKey="day" tick={{ fill: '#3a5a7a', fontSize: 8 }} />
            <YAxis tick={{ fill: '#3a5a7a', fontSize: 8 }} unit="кг" />
            <Tooltip contentStyle={{ background: '#000d1a', border: '1px solid #8B5CF644', fontSize: 10, color: '#a0d4ff' }} />
            <ReferenceLine x={11} stroke="#ff8c00" strokeDasharray="3 3" label={{ value: 'Збір', fill: '#ff8c00', fontSize: 8 }} />
            <Line type="monotone" dataKey="biomass" stroke="#8B5CF6" dot={false} strokeWidth={2} />
            <Line type="monotone" dataKey="molt" stroke="#ff2020" dot={{ fill: '#ff2020', r: 3 }} strokeWidth={0} />
          </LineChart>
        </ResponsiveContainer>
        <div style={{ display: 'flex', gap: 16, marginTop: 6 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 12, height: 2, background: '#8B5CF6' }} />
            <span style={{ fontSize: 9, color: '#3a5a7a' }}>Біомаса</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 8, height: 8, background: '#ff2020', borderRadius: '50%' }} />
            <span style={{ fontSize: 9, color: '#3a5a7a' }}>Линяння</span>
          </div>
        </div>
      </HudPanel>

      {/* JARVIS Chat */}
      <HudPanel title="JARVIS КОМУНІКАЦІЯ" color="#8B5CF6">
        <div ref={chatRef} style={{
          height: 200, overflowY: 'auto', marginBottom: 10,
          background: '#000810', borderRadius: 4, padding: 8,
        }}>
          {chatMessages.map((msg, i) => (
            <div key={i} style={{
              display: 'flex', justifyContent: msg.from === 'ai' ? 'flex-start' : 'flex-end',
              marginBottom: 8,
            }}>
              {msg.from === 'ai' && (
                <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'rgba(139,92,246,0.3)', border: '1px solid #8B5CF6', display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: 6, flexShrink: 0, fontSize: 10 }}>🧠</div>
              )}
              <div style={{
                maxWidth: '80%', padding: '7px 10px', borderRadius: 6, fontSize: 11, lineHeight: 1.4,
                background: msg.from === 'ai' ? 'rgba(0,20,60,0.8)' : 'rgba(139,92,246,0.2)',
                border: `1px solid ${msg.from === 'ai' ? 'rgba(0,150,255,0.2)' : 'rgba(139,92,246,0.3)'}`,
                color: msg.from === 'ai' ? '#a0d4ff' : '#c4b5fd',
              }}>
                {msg.text}
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            className="hud-input" style={{ flex: 1 }}
            placeholder="Запитайте JARVIS..."
            value={chatInput}
            onChange={e => setChatInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendChat(chatInput)}
          />
          <button className="btn-purple" style={{ padding: '8px 12px' }}
            onClick={() => sendChat(chatInput)}>▶</button>
        </div>
        <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
          {['як справи?', 'температура', 'линяння', 'прогноз'].map(q => (
            <button key={q}
              onClick={() => sendChat(q)}
              style={{
                fontSize: 9, padding: '3px 8px', borderRadius: 10,
                background: 'rgba(0,150,255,0.1)', border: '1px solid rgba(0,150,255,0.3)',
                color: '#3a5a7a', cursor: 'pointer',
              }}>{q}</button>
          ))}
        </div>
      </HudPanel>

      {/* Action buttons */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
        <button className="btn-purple" style={{ flex: 1 }} onClick={() => setTrainModal(true)}>
          🧬 НАВЧИТИ ШІ
        </button>
        <button className="btn-cyan" style={{ flex: 1 }} onClick={() => setReportModal(true)}>
          📊 ЗВІТ ТИЖНЯ
        </button>
      </div>

      {/* Test modal */}
      {testModal && (
        <Modal title="STARK INDUSTRIES DIAGNOSTIC" color="#ff2020" onClose={() => setTestModal(false)}>
          <div style={{ padding: '10px 0' }}>
            {testSteps.map((step, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '8px 0', borderBottom: '1px solid rgba(0,150,255,0.1)',
                opacity: testStep > i ? 1 : testStep === i ? 0.7 : 0.3,
              }}>
                <span style={{ fontSize: 14 }}>
                  {testStep > i ? '✅' : testStep === i ? '⏳' : '○'}
                </span>
                <span style={{ fontSize: 11, color: testStep > i ? '#00ff88' : '#a0d4ff' }}>{step}</span>
                {testStep > i && <span style={{ marginLeft: 'auto', fontSize: 10, color: '#00ff88' }}>PASS</span>}
              </div>
            ))}
            {testStep >= 5 && (
              <div style={{ textAlign: 'center', marginTop: 16 }}>
                <div style={{ fontSize: 13, color: '#00ff88', marginBottom: 4 }}>ALL SYSTEMS NOMINAL</div>
                <div style={{ fontSize: 10, color: '#3a5a7a' }}>FARM INTEGRITY: 100% | CRAYFISH SAFETY: CONFIRMED</div>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* Train modal */}
      {trainModal && (
        <Modal title="НАВЧИТИ ШІ — ДАНІ" color="#8B5CF6" onClose={() => setTrainModal(false)}>
          <div>
            {[
              { label: 'БАСЕЙН', type: 'select', key: 'pool', options: ['1', '2', '3'] },
              { label: 'СЕРЕДНЯ ВАГА (г)', type: 'number', key: 'weight', placeholder: '150' },
              { label: 'КІЛЬКІСТЬ ОСОБИН', type: 'number', key: 'count', placeholder: '85' },
            ].map(f => (
              <div key={f.key} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4 }}>{f.label}</div>
                {f.type === 'select' ? (
                  <select className="hud-input" value={trainData[f.key]}
                    onChange={e => setTrainData(p => ({ ...p, [f.key]: e.target.value }))}>
                    {f.options.map(o => <option key={o} value={o}>Басейн {o}</option>)}
                  </select>
                ) : (
                  <input className="hud-input" type="number" placeholder={f.placeholder}
                    value={trainData[f.key]}
                    onChange={e => setTrainData(p => ({ ...p, [f.key]: e.target.value }))} />
                )}
              </div>
            ))}
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 6 }}>СТАН ЗДОРОВ'Я</div>
              <div style={{ display: 'flex', gap: 6 }}>
                {[1, 2, 3, 4, 5].map(s => (
                  <button key={s}
                    onClick={() => setTrainData(p => ({ ...p, health: s }))}
                    style={{
                      flex: 1, padding: '8px 4px', borderRadius: 4, cursor: 'pointer',
                      background: trainData.health >= s ? 'rgba(139,92,246,0.3)' : 'rgba(0,15,40,0.5)',
                      border: `1px solid ${trainData.health >= s ? '#8B5CF6' : 'rgba(0,150,255,0.2)'}`,
                      fontSize: 14,
                    }}>⭐</button>
                ))}
              </div>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 6 }}>СТАДІЯ ЛИНЯННЯ</div>
              <div style={{ display: 'flex', gap: 6 }}>
                {['до', 'після', 'норма'].map(s => (
                  <button key={s}
                    onClick={() => setTrainData(p => ({ ...p, stage: s }))}
                    style={{
                      flex: 1, padding: '7px 4px', fontSize: 10, borderRadius: 4, cursor: 'pointer',
                      background: trainData.stage === s ? 'rgba(0,200,255,0.2)' : 'rgba(0,15,40,0.5)',
                      border: `1px solid ${trainData.stage === s ? '#00c8ff' : 'rgba(0,150,255,0.2)'}`,
                      color: trainData.stage === s ? '#00c8ff' : '#3a5a7a',
                    }}>{s}</button>
                ))}
              </div>
            </div>
            <button className="btn-purple" style={{ width: '100%' }}
              onClick={() => { alert('✅ Дані збережено! ШІ оновлює модель...'); setTrainModal(false) }}>
              ЗБЕРЕГТИ ДАНІ
            </button>
          </div>
        </Modal>
      )}

      {/* Report modal */}
      {reportModal && (
        <Modal title="ТИЖНЕВИЙ ЗВІТ ШІ" color="#00c8ff" onClose={() => setReportModal(false)}>
          <div>
            {[
              { label: 'Середня температура', value: `${config.waterTemp.toFixed(1)}°C` },
              { label: 'Кількість тривог', value: '0' },
              { label: 'Точність прогнозів', value: '91.2% (+2.1%)' },
              { label: 'Нові патерни', value: '3' },
              { label: 'ШІ дій за тиждень', value: '47' },
            ].map((r, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid rgba(0,150,255,0.1)' }}>
                <span style={{ fontSize: 11, color: '#3a5a7a' }}>{r.label}</span>
                <span style={{ fontSize: 11, color: '#00c8ff' }}>{r.value}</span>
              </div>
            ))}
            <div style={{ marginTop: 12, padding: 10, background: 'rgba(0,255,136,0.05)', border: '1px solid rgba(0,255,136,0.2)', borderRadius: 4 }}>
              <div style={{ fontSize: 9, color: '#3a5a7a', marginBottom: 4 }}>РЕКОМЕНДАЦІЯ:</div>
              <div style={{ fontSize: 11, color: '#00ff88' }}>Збільшити кальцій у корм Басейн 2. Очікуване линяння через ~3 дні.</div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}
