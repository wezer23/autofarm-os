import React from 'react'

export default function SensorCard({ label, value, unit, status = 'normal' }) {
  const colors = {
    normal: '#00ff88',
    warning: '#ff8c00',
    critical: '#ff2020',
  }
  const color = colors[status]

  return (
    <div style={{
      background: 'rgba(0,15,40,0.8)',
      border: `1px solid ${color}33`,
      borderRadius: 4,
      padding: '10px 8px',
      textAlign: 'center',
    }}>
      <div style={{ fontSize: 9, color: '#3a5a7a', letterSpacing: '0.15em', marginBottom: 4, textTransform: 'uppercase' }}>
        {label}
      </div>
      <div style={{
        fontSize: 22,
        fontWeight: 'bold',
        color,
        textShadow: `0 0 10px ${color}`,
        lineHeight: 1,
        fontFamily: 'Courier New, monospace',
      }}>
        {value}
      </div>
      <div style={{ fontSize: 9, color: '#3a5a7a', marginTop: 2 }}>{unit}</div>
    </div>
  )
}
