import React from 'react'

const tabs = [
  { id: 'home', label: 'ГОЛОВНА', icon: '🏠' },
  { id: 'equipment', label: 'СИСТЕМИ', icon: '⚙️' },
  { id: 'map', label: 'КАРТА', icon: '🗺️' },
  { id: 'ai', label: 'JARVIS', icon: '🧠' },
  { id: 'settings', label: 'КОНФІГ', icon: '🔧' },
]

export default function BottomNav({ active, onChange }) {
  return (
    <div style={{
      position: 'fixed',
      bottom: 0, left: '50%',
      transform: 'translateX(-50%)',
      width: '100%',
      maxWidth: 430,
      background: 'rgba(0,8,24,0.95)',
      borderTop: '1px solid rgba(0,150,255,0.4)',
      boxShadow: '0 -4px 20px rgba(0,100,255,0.15)',
      display: 'flex',
      zIndex: 100,
      height: 65,
    }}>
      {tabs.map(tab => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 2,
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: '4px 0',
            position: 'relative',
          }}
        >
          {active === tab.id && (
            <div style={{
              position: 'absolute',
              top: 0, left: '20%', right: '20%',
              height: 2,
              background: '#00c8ff',
              boxShadow: '0 0 8px #00c8ff',
              borderRadius: '0 0 2px 2px',
            }} />
          )}
          <span style={{ fontSize: active === tab.id ? 18 : 16 }}>{tab.icon}</span>
          <span style={{
            fontSize: 9,
            letterSpacing: '0.05em',
            fontFamily: 'Courier New, monospace',
            color: active === tab.id ? '#00c8ff' : '#3a5a7a',
            textShadow: active === tab.id ? '0 0 8px #00c8ff' : 'none',
            fontWeight: active === tab.id ? 'bold' : 'normal',
          }}>
            {tab.label}
          </span>
        </button>
      ))}
    </div>
  )
}
