import React, { useState, useEffect } from 'react'

export default function PWAInstall() {
  const [canInstall, setCanInstall] = useState(false)
  const [installed, setInstalled] = useState(false)
  const [installing, setInstalling] = useState(false)

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setInstalled(true)
      return
    }

    // Listen for install prompt
    const onInstallable = () => setCanInstall(true)
    const onInstalled = () => {
      setInstalled(true)
      setCanInstall(false)
    }

    window.addEventListener('pwa-installable', onInstallable)
    window.addEventListener('pwa-installed', onInstalled)

    return () => {
      window.removeEventListener('pwa-installable', onInstallable)
      window.removeEventListener('pwa-installed', onInstalled)
    }
  }, [])

  const handleInstall = async () => {
    if (!window.installPWA) return
    setInstalling(true)
    try {
      const outcome = await window.installPWA()
      if (outcome === 'accepted') {
        setInstalled(true)
        setCanInstall(false)
      }
    } catch (err) {
      console.error('Install error:', err)
    }
    setInstalling(false)
  }

  // Already installed as PWA
  if (installed) {
    return (
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '4px 10px',
        background: 'rgba(0,255,136,0.1)',
        border: '1px solid rgba(0,255,136,0.3)',
        borderRadius: 4,
        fontSize: 9,
        color: '#00ff88',
        letterSpacing: '0.1em',
      }}>
        <span>✓</span> ВСТАНОВЛЕНО
      </div>
    )
  }

  // Can install
  if (canInstall) {
    return (
      <button
        onClick={handleInstall}
        disabled={installing}
        style={{
          background: installing ? 'rgba(0,200,255,0.05)' : 'rgba(0,200,255,0.15)',
          border: '1px solid #00c8ff',
          color: '#00c8ff',
          padding: '6px 12px',
          borderRadius: 4,
          fontFamily: 'Courier New, monospace',
          fontSize: 9,
          letterSpacing: '0.1em',
          cursor: installing ? 'wait' : 'pointer',
          textTransform: 'uppercase',
          boxShadow: '0 0 10px rgba(0,200,255,0.3)',
          animation: 'none',
        }}
      >
        {installing ? '⏳ ВСТАНОВЛЕННЯ...' : '📲 ВСТАНОВИТИ ДОДАТОК'}
      </button>
    )
  }

  // iOS hint (iOS doesn't support beforeinstallprompt)
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
  if (isIOS && !installed) {
    return (
      <div style={{
        fontSize: 9, color: '#3a5a7a',
        padding: '4px 8px',
        border: '1px solid rgba(0,150,255,0.2)',
        borderRadius: 4,
        letterSpacing: '0.05em',
      }}>
        📲 Share → "На екран"
      </div>
    )
  }

  return null
}
