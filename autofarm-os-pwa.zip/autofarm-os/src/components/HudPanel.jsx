import React from 'react'

export default function HudPanel({ title, children, color = '#00c8ff', className = '', style = {} }) {
  return (
    <div className={`hud-panel ${className}`} style={{ padding: '12px', marginBottom: '10px', ...style }}>
      {title && (
        <div style={{
          fontSize: 10,
          letterSpacing: '0.2em',
          color: color,
          textTransform: 'uppercase',
          marginBottom: 10,
          display: 'flex',
          alignItems: 'center',
          gap: 6,
        }}>
          <span style={{ opacity: 0.5 }}>◈</span>
          {title}
          <div style={{ flex: 1, height: 1, background: `linear-gradient(90deg, ${color}44, transparent)`, marginLeft: 4 }} />
        </div>
      )}
      {children}
    </div>
  )
}
