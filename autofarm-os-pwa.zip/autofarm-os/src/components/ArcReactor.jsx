import React from 'react'

export default function ArcReactor({ size = 80, status = 'normal' }) {
  const colors = {
    normal: '#00ffff',
    thinking: '#ffaa00',
    alert: '#ff2020',
    offline: '#334466',
  }
  const color = colors[status] || colors.normal

  return (
    <div style={{ width: size, height: size, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      {/* Outer ring */}
      <div className="arc-outer" style={{
        position: 'absolute',
        width: size, height: size,
        borderRadius: '50%',
        border: `2px dashed ${color}`,
        opacity: 0.6,
      }} />
      {/* Middle ring */}
      <div className="arc-middle" style={{
        position: 'absolute',
        width: size * 0.75, height: size * 0.75,
        borderRadius: '50%',
        border: `1px solid ${color}`,
        borderTopColor: 'transparent',
        borderBottomColor: 'transparent',
        opacity: 0.8,
      }} />
      {/* Inner ring */}
      <div className="arc-inner" style={{
        position: 'absolute',
        width: size * 0.5, height: size * 0.5,
        borderRadius: '50%',
        border: `2px solid ${color}`,
        borderLeftColor: 'transparent',
        opacity: 0.9,
      }} />
      {/* Core */}
      <div className="arc-core" style={{
        width: size * 0.28, height: size * 0.28,
        borderRadius: '50%',
        background: `radial-gradient(circle, white 0%, ${color} 60%, transparent 100%)`,
        boxShadow: `0 0 ${size * 0.25}px ${color}, 0 0 ${size * 0.5}px rgba(0,255,255,0.3)`,
      }} />
    </div>
  )
}
