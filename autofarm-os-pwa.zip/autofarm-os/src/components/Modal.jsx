import React from 'react'

export default function Modal({ title, children, onClose, color = '#00c8ff' }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="hud-panel"
        style={{ width: '100%', maxWidth: 380, maxHeight: '80vh', overflow: 'auto' }}
        onClick={e => e.stopPropagation()}
      >
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          marginBottom: 16, borderBottom: `1px solid ${color}33`, paddingBottom: 10,
        }}>
          <div style={{ fontSize: 12, color, letterSpacing: '0.2em', textTransform: 'uppercase' }}>
            ◈ {title}
          </div>
          <button
            onClick={onClose}
            style={{ background: 'none', border: 'none', color: '#3a5a7a', fontSize: 18, cursor: 'pointer' }}
          >✕</button>
        </div>
        {children}
      </div>
    </div>
  )
}
