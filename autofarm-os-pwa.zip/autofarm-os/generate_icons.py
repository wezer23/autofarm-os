#!/usr/bin/env python3
"""Generate PWA icons for AutoFarm OS"""
import os

# Create icons directory
os.makedirs('/home/claude/autofarm-os/public/icons', exist_ok=True)

# SVG arc reactor icon
svg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <rect width="512" height="512" fill="#000510"/>
  <!-- Outer ring -->
  <circle cx="256" cy="256" r="220" fill="none" stroke="#00c8ff" stroke-width="8" stroke-dasharray="20 10" opacity="0.8"/>
  <!-- Middle ring -->
  <circle cx="256" cy="256" r="170" fill="none" stroke="#0080ff" stroke-width="6" opacity="0.7"/>
  <!-- Inner ring -->
  <circle cx="256" cy="256" r="120" fill="none" stroke="#00c8ff" stroke-width="4" opacity="0.9"/>
  <!-- Core glow -->
  <circle cx="256" cy="256" r="80" fill="url(#coreGrad)" opacity="0.95"/>
  <!-- Crayfish emoji area -->
  <text x="256" y="290" text-anchor="middle" font-size="100" fill="#ff3b30">🦞</text>
  <!-- Gradient -->
  <defs>
    <radialGradient id="coreGrad" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.9"/>
      <stop offset="40%" stop-color="#00ffff" stop-opacity="0.8"/>
      <stop offset="100%" stop-color="#000510" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <!-- Hex grid pattern hint -->
  <polygon points="256,36 296,60 296,108 256,132 216,108 216,60" fill="none" stroke="#00c8ff" stroke-width="1" opacity="0.15"/>
</svg>'''

with open('/home/claude/autofarm-os/public/icons/icon.svg', 'w') as f:
    f.write(svg)

print("SVG icon created")

# Try to generate PNG icons using PIL if available
try:
    from PIL import Image, ImageDraw
    import io

    sizes = [72, 96, 128, 144, 152, 192, 384, 512]

    for size in sizes:
        img = Image.new('RGBA', (size, size), (0, 5, 16, 255))
        draw = ImageDraw.Draw(img)

        cx, cy = size // 2, size // 2
        r = size // 2

        # Background circle
        draw.ellipse([cx-r+2, cy-r+2, cx+r-2, cy+r-2],
                    fill=(0, 10, 30, 255),
                    outline=(0, 200, 255, 200),
                    width=max(1, size//64))

        # Middle ring
        r2 = int(r * 0.75)
        draw.ellipse([cx-r2, cy-r2, cx+r2, cy+r2],
                    fill=None,
                    outline=(0, 128, 255, 150),
                    width=max(1, size//80))

        # Inner ring
        r3 = int(r * 0.5)
        draw.ellipse([cx-r3, cy-r3, cx+r3, cy+r3],
                    fill=None,
                    outline=(0, 200, 255, 200),
                    width=max(1, size//96))

        # Core glow
        r4 = int(r * 0.28)
        draw.ellipse([cx-r4, cy-r4, cx+r4, cy+r4],
                    fill=(0, 220, 255, 230))

        # Center white dot
        r5 = int(r * 0.12)
        draw.ellipse([cx-r5, cy-r5, cx+r5, cy+r5],
                    fill=(255, 255, 255, 255))

        img.save(f'/home/claude/autofarm-os/public/icons/icon-{size}.png', 'PNG')
        print(f"Created icon-{size}.png")

    print("All PNG icons created with PIL!")

except ImportError:
    print("PIL not available, creating placeholder PNGs...")
    # Create minimal valid PNG (1x1 blue pixel scaled)
    import struct
    import zlib

    def create_simple_png(size, color=(0, 200, 255)):
        """Create a simple solid color PNG"""
        width = height = size
        # PNG signature
        sig = b'\x89PNG\r\n\x1a\n'

        # IHDR chunk
        ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
        ihdr_crc = zlib.crc32(b'IHDR' + ihdr_data)
        ihdr = struct.pack('>I', 13) + b'IHDR' + ihdr_data + struct.pack('>I', ihdr_crc)

        # IDAT chunk - image data
        raw_data = b''
        for y in range(height):
            raw_data += b'\x00'  # filter byte
            for x in range(width):
                # Draw arc reactor pattern
                dx = x - width // 2
                dy = y - height // 2
                dist = (dx*dx + dy*dy) ** 0.5
                r = width // 2

                if dist < r * 0.15:  # core
                    raw_data += bytes([255, 255, 255])
                elif dist < r * 0.3:  # inner glow
                    raw_data += bytes([0, 220, 255])
                elif dist < r * 0.32:  # inner ring
                    raw_data += bytes([0, 200, 255])
                elif dist < r * 0.5:  # mid area
                    raw_data += bytes([0, 30, 60])
                elif dist < r * 0.52:  # mid ring
                    raw_data += bytes([0, 128, 255])
                elif dist < r * 0.75:  # outer area
                    raw_data += bytes([0, 15, 40])
                elif dist < r * 0.77:  # outer ring
                    raw_data += bytes([0, 200, 255])
                elif dist < r:  # bg
                    raw_data += bytes([0, 5, 16])
                else:
                    raw_data += bytes([0, 5, 16])

        compressed = zlib.compress(raw_data)
        idat_crc = zlib.crc32(b'IDAT' + compressed)
        idat = struct.pack('>I', len(compressed)) + b'IDAT' + compressed + struct.pack('>I', idat_crc)

        # IEND chunk
        iend_crc = zlib.crc32(b'IEND')
        iend = struct.pack('>I', 0) + b'IEND' + struct.pack('>I', iend_crc)

        return sig + ihdr + idat + iend

    sizes = [72, 96, 128, 144, 152, 192, 384, 512]
    for size in sizes:
        png_data = create_simple_png(size)
        with open(f'/home/claude/autofarm-os/public/icons/icon-{size}.png', 'wb') as f:
            f.write(png_data)
        print(f"Created icon-{size}.png ({size}x{size})")

    print("All placeholder icons created!")
